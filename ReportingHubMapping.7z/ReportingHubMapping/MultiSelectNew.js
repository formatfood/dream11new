
/**
* @author zhixin wen <wenzhixin2010@gmail.com>
* @version 1.1.0
* 
* http://wenzhixin.net.cn/p/multiple-select/
*/

(function($) {

    'use strict';

    // it only does '%s', and return '' when arguments are undefined
    var sprintf = function(str) {
        var args = arguments,
            flag = true,
            i = 1;

        str = str.replace(/%s/g, function() {
            var arg = args[i++];

            if (typeof arg === 'undefined') {
                flag = false;
                return '';
            }
            return arg;
        });
        return flag ? str : '';
    };
    function MultipleSelect($el, options) {
        var that = this,
            name = $el.attr('name') || options.name || '',
            elWidth = $el.outerWidth();

        this.$el = $el.hide();
        this.options = options;
        this.$parent = $('<div id="' + name + '" ' + $.map(['class', 'title'], function(att) {
            var attValue = that.$el.attr(att) || '';
            attValue = (att === 'class' ? ('ms-parent' + (attValue ? ' ' : '')) : '') + attValue;
            return attValue ? (' ' + att + '="' + attValue + '"') : '';
        }).join('') + '>');
        this.$choice = $('<button type="button" id="btn' + name + '" class="ms-choice"><span class="placeholder">' +
            options.placeholder + '</span><div></div></button>');
        this.$drop = $('<div class="ms-drop ' + options.position + '" id="div' + name + '"></div>');
        this.$el.after(this.$parent);
        this.$parent.append(this.$choice);
        this.$parent.append(this.$drop);

        if (this.$el.prop('disabled')) {
            this.$choice.addClass('disabled');
        }
        //this.$parent.css('width', options.width || elWidth);  ////commmented for CR - #1454

        if (!this.options.keepOpen) {
            $('body').bind('mouseup keyup', function(e) {           ///// modified for CR- #1454
                if (e.which !== 13) {
                    if ($(e.target)[0] === that.$choice[0] ||
                    $(e.target).parents('.ms-choice')[0] === that.$choice[0]) {
                        return;
                    }
                    if (($(e.target)[0] === that.$drop[0] ||
                    $(e.target).parents('.ms-drop')[0] !== that.$drop[0]) &&
                    that.options.isOpen) {
                        ////Added codition for CR - 1454
                        if (name != 'PopulationCriteria' && name != 'SelectedPopulationCriteria') {
                            //alert('inside main');
                            that.close();
                        }
                    }
                }
            });
        }

        this.selectAllName = 'name="selectAll' + name + '"';
        this.selectGroupName = 'name="selectGroup' + name + '"';
        this.selectItemName = 'name="selectItem' + name + '"';
        this.selectAllId = 'id="selectAll' + name + '"';
        this.ControlName = name;   /////Added for 1454 
    }

    MultipleSelect.prototype = {
        constructor: MultipleSelect,

        init: function() {
            var that = this,
                html = [];
            if (this.options.filter) {
                /////Added for 1454 
                if (this.ControlName === 'PopulationCriteria') {
                    //                    html.push(
                    //                        '<div class="msTop"><div class="row-fluid">',
                    //                        '<div class="span3"><div class="form-inline">',
                    //                        '<label class="radio inline"><input type="radio" id="PatientSp" name="PatientSp" value="And"> And</label>',
                    //                        '<label class="radio inline"><input type="radio" id="PatientSp" name="PatientSp" value="Or" checked="checked"> Or</label>',
                    //                        '</div></div><div class="span9">',
                    //                        '<div class="ms-search">',
                    //                            '<input id="ip' + this.ControlName + '" placeholder="Search Parameters" type="text" class="span12" autocomplete="off" autocorrect="off" autocapitilize="off" spellcheck="false">',   ///// onkeypress="call();"
                    //                        '<button type="button" class="ms-btnSearch"></button>',
                    //                        '</div></div></div></div>'
                    //                    );
                    /////Added for 1454 
                }
                else {
                    html.push(
                    '<div class="msTop"><div class="row-fluid">' +
                    ((this.options.isLazyLoading) ? '<label class="limitmessage">' + this.options.limitMessage + '</label>' : '') +
                    '<div class="' + this.options.searchdesignclass + '"><div class="ms-search">',
                        '<input id="ip' + this.ControlName + '" type="text" class="span12 ms-textbox" autocomplete="off" autocorrect="off" autocapitilize="off" spellcheck="false"' +
                        (this.ControlName === "SelectedPopulationCriteria" ? ' placeholder="Search Parameters" >' : ' >') +
                        '<button type="button" class="ms-btnSearch"></button></div></div>' +
                        (this.options.selectAll ? '<div class="span3"><label  class="checkbox mTop3"> <input type="checkbox" '
                        + this.selectAllName + ' ' + this.selectAllId + ' /> ' + this.options.selectAllDefaultName + '</label></div>' : '') +
                    '</div></div>'
                );
                }
            }
            else {
                html.push(
                    '<div class="msTop"><div class="row-fluid">' +
                        (this.options.selectAll ? '<div class="span6 "><label  class="checkbox mTop3"> <input type="checkbox" '
                        + this.selectAllName + ' ' + this.selectAllId + ' /> ' + this.options.selectAllDefaultName + '</label></div>' : '') +
                    '</div></div>'
                );
            }
            html.push('<div class="msMHeight"><ul>');
            ///Commented for CR-#1454
            // if (this.options.selectAll && !this.options.single && this.options.isReportPage) {
            //     html.push(
            //                     '<li class="ms-select-all">',
            //                         '<label  class="checkbox">',
            //                             '<input type="checkbox" ' + this.selectAllName + ' ' + this.selectAllId + ' /> ',
            //                             '[' + this.options.selectAllText + ']',
            //                         '</label>',
            //                     '</li>'
            //                 );
            // }

            if (this.options.isLazyLoading) {
                //alert(this.options.controlId);
                var cid = this.options.controlId;
                var limitedData = this.options.controlData.slice(0, this.options.initItemLimit);
                $.each(limitedData, function(i, item) {
                    if(item.S == true)
                    html.push(that.optionToGenerateHtml(item.T, item.V, item.S, false));
                });
                $.each(limitedData, function(i, item) {
                    if (item.S == false)
                        html.push(that.optionToGenerateHtml(item.T, item.V, item.S, false));
                });
            }
            else {
                $.each(this.$el.children(), function(i, elm) {
                    html.push(that.optionToHtml(i, elm));
                });
            }
            html.push('<li class="ms-no-results">' + this.options.noMatchesFound + '</li>');
            html.push('</ul></div>');
            this.$drop.html(html.join(''));

            //this.$drop.find('ul').css('height', this.options.fixHeight + 'px');         /// Commented for CR 1454
            //this.$drop.find('.multiple').css('width', this.options.multipleWidth + 'px');  /// Commented for CR 1454

            this.$searchInput = this.$drop.find('.ms-search .ms-btnSearch');
            this.$searchInputText = this.$drop.find('.ms-search .ms-textbox'); //Added on CR 4936
            this.$selectAll = this.$drop.find('input[' + this.selectAllName + ']');
            this.$selectGroups = this.$drop.find('input[' + this.selectGroupName + ']');
            this.$selectItems = this.$drop.find('input[' + this.selectItemName + ']');   //// removed :enabled from the find
            this.$disableItems = this.$drop.find('input[' + this.selectItemName + ']:disabled');
            this.$noResults = this.$drop.find('.ms-no-results');
            if (this.options.isLazyLoading) {
                this.$limitMessage = this.$drop.find('.limitmessage');
            }
            this.events();
            this.update(true);

            if (this.options.isOpen) {
                this.open();
            }
        },
        optionToGenerateHtml: function(pText, pValue, pSelected, group, isfilter) {

            var multiple = this.options.multiple ? 'multiple' : '',
                classes = pSelected ? 'clearfix selected' : 'clearfix',
            title = pText,
                style = '',
            disabled = false,
            type = 'checkbox',
            selected = pSelected,
            $el, cid = this.options.controlId;

            $el = $([
                    sprintf('<li  class="%s %s" %s %s>', multiple, classes, title, style),
                    sprintf('<label class="%s">', disabled ? 'checkbox disabled' : 'checkbox'),
                    sprintf('<input data-controlId="%s"" type="%s" %s%s%s%s value="' + pText + '">',
                      cid, type, this.selectItemName,
                        pSelected ? ' checked="checked"' : '',
                        disabled ? ' disabled="disabled"' : '',
                        sprintf(' data-group="%s"', group)),
                    sprintf('<span>%s</span>', pText),
                    '</label>',
                    '</li>'
                ].join(''));
            $el.find('input').val(pValue);

            return '<li class="' + multiple + ' ' + classes + ' ' + style + '">' + $el.html() + '</li>';

        },
        optionToHtml: function(i, elm, group, groupDisabled) {
            var that = this,
                $elm = $(elm),
                html = [],
                multiple = this.options.multiple,
                optAttributesToCopy = ['class', 'title'],
                clss = $.map(optAttributesToCopy, function(att, i) {
                    var isMultiple = att === 'class' && multiple;
                    var attValue = $elm.attr(att) || '';
                    return (isMultiple || attValue) ?
                        (' ' + att + '="' + (isMultiple ? ('multiple clearfix' + (attValue ? ' ' : '')) : '') + attValue + '"') :
                        '';
                }).join(''),
                disabled,
                type = this.options.single ? 'radio' : 'checkbox';
            disabled = groupDisabled || $elm.prop('disabled');
            clss = (clss === '' ? clss = ' class="clearfix ' + (disabled ? ' disabled' : '') + '"' : clss);   //// added for #1454 CR
            if ($elm.is('option')) {
                var value = $elm.val(),
                    text = $elm.text(),
                    selected = (that.$el.attr('multiple') != undefined) ? $elm.prop('selected') : ($elm.attr('selected') == 'selected'),
                    style = this.options.styler(value) ? ' style="' + this.options.styler(value) + '"' : '';

                //disabled = groupDisabled || $elm.prop('disabled');  
                if ((this.options.blockSeparator > "") && (this.options.blockSeparator == $elm.val())) {
                    html.push(
                            '<li' + clss + style + '>',
                                '<label class="checkbox ' + this.options.blockSeparator + (disabled ? 'disabled' : '') + '">',
                                    text,
                                '</label>',
                            '</li>'
                    );
                }
                else {
                    html.push(
                            '<li' + clss + style + '>',
                                '<label class="checkbox' + (disabled ? ' disabled' : '') + '">',
                                    '<input type="' + type + '" ' + this.selectItemName + ' id="' + value + '" value="' + value + '"' +      ////Added hideOptionCheckboxes as an option for input for CR #1454 
                                        (selected ? ' checked="checked"' : '') +
                                        (disabled ? ' disabled="disabled"' : '') +
                                        (group ? ' data-group="' + group + '"' : '') +
                                        (this.options.hideOptionCheckboxes ? ' disabled="disabled" checked="checked"' : '') +
                                        '/> ',
                                    text,
                                '</label>',
                            '</li>'
                    );
                }
            } else if (!group && $elm.is('optgroup')) {
                var _group = 'group_' + i,
                    label = $elm.attr('label');

                disabled = $elm.prop('disabled');
                if (this.ControlName === 'SelectedPopulationCriteria') {
                    html.push(
                    '<li class="group clearfix"><button type="button" class="ms-expand collapsed" id="' + _group + '"></button>',  //// Added </ul> for CR - 1454
                        '<label class="checkbox optgroup' + (disabled ? ' disabled' : '') + '" data-group="' + _group + '">',
                            '<input type="checkbox" ' + this.selectGroupName +
                                (disabled ? ' disabled="disabled"' : '') +
                                (this.options.hideOptgroupCheckboxes ? ' disabled="disabled" checked="checked" style="display:none;"' : '') +
                                 ' id="2' + _group + '" /> ',   ////Added id to optgroup input for CR #1454 
                            label,
                        '</label>',
                    '</li><ul  id="1' + _group + '" style="height:0;overflow: hidden;">');  //// Added <ul> for CR - 1454
                }
                else {
                    html.push(
                    '<li class="group clearfix"><button type="button" class="ms-expand collapsed" data-toggle="collapse" data-target="#1' + _group + '"></button>',  //// Added </ul> for CR - 1454
                        '<label class="checkbox optgroup' + (disabled ? ' disabled' : '') + '" data-group="' + _group + '">',
                            '<input type="checkbox" ' + this.selectGroupName +
                                (disabled ? ' disabled="disabled"' : '') +
                                (this.options.hideOptgroupCheckboxes ? ' disabled="disabled" checked="checked" style="display:none;"' : '') +
                                 ' id="' + _group + '" /> ',   ////Added id to optgroup input for CR #1454 
                            label,
                        '</label>',
                    '</li><ul id="1' + _group + '" class="collapse">');  //// Added <ul> for CR - 1454
                }

                $.each($elm.children(), function(i, elm) {
                    html.push(that.optionToHtml(i, elm, _group, disabled));
                });
                html.push('</ul>'); //// Added <ul> for CR - 1454   ms-lblList
            }
            return html.join('');
        },

        events: function() {
            var that = this;
            function toggleOpen(e) {
                e.preventDefault();
                that[that.options.isOpen ? 'close' : 'open']();
            }
            var label = this.$el.parent().closest('label')[0] || $('label[for=' + this.$el.attr('id') + ']')[0];
            if (label) {
                $(label).off('click').on('click', function(e) {
                    if (e.target.nodeName.toLowerCase() !== 'label' || e.target !== this) {
                        return;
                    }
                    toggleOpen(e);
                    if (!that.options.filter || !that.options.isOpen) {
                        that.focus();
                    }
                    e.stopPropagation(); // Causes lost focus otherwise
                });
            }
            this.$choice.off('click').on('click', toggleOpen)
                .off('focus').on('focus', this.options.onFocus)
                .off('blur').on('blur', this.options.onBlur);

            this.$parent.off('keydown').on('keydown', function(e) {
                switch (e.which) {
                    case 27: // esc key
                        that.close();
                        that.$choice.focus();
                        break;
                }
            });
            this.$searchInput.off('click').on('click', function(e) {  ///changed from key events to click event fro CR-#1454
                if (e.keyCode === 9 && e.shiftKey) { // Ensure shift-tab causes lost focus from filter as with clicking away
                    that.close();
                }
            }).off('click').on('click', function(e) {   ///changed from key events to click event fro CR-#1454
                if (that.options.filterAcceptOnEnter &&
                              (e.which === 13 || e.which == 32) && // enter or space
                              that.$searchInput.parent().find('input').val() // Avoid selecting/deselecting if no choices made
                          ) {
                    that.$selectAll.click();
                    that.close();
                    that.focus();
                    return;
                }
                that.filter();
            });
            /*Added on 4936*/
            if (this.options.onkeyupsearchrequired) {
                this.$searchInputText.off('keyup').on('keyup', function(e) {  ///changed from key events to click event fro CR-#1454
                    if (e.keyCode === 9 && e.shiftKey) { // Ensure shift-tab causes lost focus from filter as with clicking away
                        that.close();
                    }
                }).off('keyup').on('keyup', function(e) {   ///changed from key events to click event fro CR-#1454
                    if (that.options.filterAcceptOnEnter &&
                              (e.which === 13 || e.which == 32) && // enter or space
                              that.$searchInput.parent().find('input').val() // Avoid selecting/deselecting if no choices made
                          ) {
                        that.$selectAll.click();
                        that.close();
                        that.focus();
                        return;
                    }
                    if (that.$searchInputText.val().length > that.options.keyupstartsdigit || e.which == 8) {
                        that.filter();
                    }
                });
            }
            /*Added on 4936*/
            this.$selectAll.off('click').on('click', function() {
                var checked = $(this).prop('checked'),
                    $items = that.$selectItems.filter(':enabled:visible');
                //                if (that.options.isLazyLoading) {
                //                    that[checked ? 'checkAll' : 'uncheckAll']();
                //                }
                if ($items.length === that.$selectItems.length) {
                    that[checked ? 'checkAll' : 'uncheckAll']();
                } else { // when the filter option is true
                    that.$selectGroups.prop('checked', checked);
                    $items.prop('checked', checked);
                    that.options[checked ? 'onCheckAll' : 'onUncheckAll']();
                    ///added for CR-#1454
                    if (checked) {
                        $items.parent().parent().addClass('selected');
                        that.$selectGroups.parent().addClass('selected');
                    }
                    else {
                        $items.parent().parent().removeClass('selected');
                        that.$selectGroups.parent().removeClass('selected');
                    }
                    ///added for CR-#1454
                    that.update();
                    //that.close();  ///commmented for CR-#1454
                }
            });
            this.$selectGroups.off('click').on('click', function() {
                var group = $(this).parent().attr('data-group'),
                    $items = that.$selectItems.filter(':enabled:visible'),   ///// modified from .filter(':visible') to .filter(':enabled:visible') for CR 1454
                    $children = $items.filter('[data-group="' + group + '"]'),
                    checked = $children.length !== $children.filter(':enabled:checked').length;
                $children.prop('checked', checked);
                that.updateSelectAll();
                that.update();
                //////Added for CR - 1454
                if (checked) {
                    $(this).parent().parent().addClass('selected');
                    $children.parent().parent().addClass('selected');
                }
                else {
                    $(this).parent().parent().removeClass('selected');
                    $children.parent().parent().removeClass('selected');
                }
                //////Added for CR - 1454
                that.options.onOptgroupClick({
                    label: $(this).parent().text(),
                    checked: checked,
                    children: $children.get()
                });
            });
            this.$selectItems.off('click').on('click', function() {
                that.updateSelectAll();
                that.update();
                that.updateOptGroupSelect();
                //////Added for CR - 1454
                if ($(this).prop('checked')) {
                    $(this).parent().parent().addClass('selected');
                }
                else {
                    $(this).parent().parent().removeClass('selected');
                }
                //////Added for CR - 1454
                that.options.onClick({
                    label: $(this).parent().text(),
                    value: $(this).val(),
                    checked: $(this).prop('checked')
                });

                if (that.options.single && that.options.isOpen && !that.options.keepOpen) {
                    that.close();
                }
            });
        },


        open: function() {
            if (this.$choice.hasClass('disabled')) {
                return;
            }
            this.options.isOpen = true;
            this.$choice.find('>div').addClass('open');
            this.$drop.show();

            // fix filter bug: no results show
            this.$selectAll.parent().show();
            this.$noResults.hide();
            if (this.options.isLazyLoading) {
                this.$limitMessage.hide();
            }
            // Fix #77: 'All selected' when no options
            if (this.$el.children().length === 0) {
                this.$selectAll.parent().hide();
                this.$noResults.show();
            }

            if (this.options.container) {
                var offset = this.$drop.offset();
                this.$drop.appendTo($(this.options.container));
                this.$drop.offset({ top: offset.top, left: offset.left });
            }
            ////Added if condition for CR-#1454
            if (this.ControlName != 'PopulationCriteria' && this.ControlName != 'SelectedPopulationCriteria') {
                if (this.options.filter) {
                    this.$searchInput.parent().find('input').val('');    /////modified for CR-#1454
                    this.$searchInput.parent().find('input').focus();    /////modified for CR-#1454
                    this.filter();
                }
            }
            ////Added if condition for CR-#1454
            this.options.onOpen();
        },

        close: function() {
            this.options.isOpen = false;
            this.$choice.find('>div').removeClass('open');
            this.$drop.hide();
            if (this.options.container) {
                this.$parent.append(this.$drop);
                this.$drop.css({
                    'top': 'auto',
                    'left': 'auto'
                });
            }
            this.options.onClose();
        },

        update: function(isInit) {
            var selects = this.getSelects(),
                $span = this.$choice.find('>span');
            var countDetails = [];
            if (this.options.isLazyLoading) { countDetails = this.getCountAndSelected(this); }
            if (selects.length === 0) {
                $span.addClass('placeholder').html(this.options.placeholder);
            } else if (this.options.countSelected && selects.length < this.options.minumimCountSelected) {
                $span.removeClass('placeholder').html(
                    (this.options.displayValues ? selects : this.getSelects('text'))
                    .join(this.options.delimiter));
            } else if (this.options.allSelected && selects.length === this.$selectItems.length + this.$disableItems.length) {
                $span.removeClass('placeholder').html(this.options.allSelected);
            }
            else if (this.options.isLazyLoading && this.options.allSelected && countDetails[0] == countDetails[1]) {
                $span.removeClass('placeholder').html(this.options.allSelected);
            } else if (this.options.countSelected && selects.length > this.options.minumimCountSelected) {
                if (this.options.isLazyLoading) {

                    $span.removeClass('placeholder').html(this.options.countSelected
                    .replace('#', countDetails[1])
                    .replace('%', countDetails[0] + this.$disableItems.length));
                }
                else {
                    $span.removeClass('placeholder').html(this.options.countSelected
                    .replace('#', selects.length)
                    .replace('%', this.$selectItems.length + this.$disableItems.length));
                }
            } else {
                $span.removeClass('placeholder').html(
                    (this.options.displayValues ? selects : this.getSelects('text'))
                    .join(this.options.delimiter));
            }
            // set selects to select
            this.$el.val(this.getSelects());

            // trigger <select> change event
            if (!isInit) {
                this.$el.trigger('change');
            }
        },

        updateSelectAll: function() {
            if (!this.options.isLazyLoading) {
                var $items = this.$selectItems.filter(':visible');
                this.$selectAll.prop('checked', $items.length &&
                $items.length === $items.filter(':checked').length);
                if (this.$selectAll.prop('checked')) {
                    this.options.onCheckAll();
                }
            }
            else {
                var counts = this.getCountAndSelected(this);
                this.$selectAll.prop('checked', counts[0] && counts[0] === counts[1]);
                if (this.$selectAll.prop('checked')) {
                    this.options.onCheckAll();
                }
            }

        },

        updateOptGroupSelect: function() {
            var $items = this.$selectItems.filter(':visible');
            $.each(this.$selectGroups, function(i, val) {
                var group = $(val).parent().attr('data-group'),
                    $children = $items.filter('[data-group="' + group + '"]');
                $(val).prop('checked', $children.length &&
                    $children.length === $children.filter(':checked').length);
                ///added for CR - 1454
                if ($(val).prop('checked') && $(val).attr('disabled') != 'disabled') {
                    $(val).parent().parent().addClass('selected');
                }
                else {
                    $(val).parent().parent().removeClass('selected');
                }
                ///added for CR - 1454
            });
        },

        //value or text, default: 'value'
        getSelects: function(type) {
            var that = this,
                texts = [],
                values = [];
            if (!that.options.isLazyLoading) {
                this.$drop.find('input[' + this.selectItemName + ']:checked').each(function() {
                    texts.push($(this).parent().text());
                    values.push($(this).val());
                });

                if (type === 'text' && this.$selectGroups.length) {
                    texts = [];
                    this.$selectGroups.each(function() {
                        var html = [],
                        text = $.trim($(this).parent().text()),
                        group = $(this).parent().data('group'),
                        $children = that.$drop.find('[' + that.selectItemName + '][data-group="' + group + '"]'),
                        $selected = $children.filter(':checked');

                        if ($selected.length === 0) {
                            return;
                        }

                        html.push('[');
                        html.push(text);
                        if ($children.length > $selected.length) {
                            var list = [];
                            $selected.each(function() {
                                list.push($(this).parent().text());
                            });
                            html.push(': ' + list.join(', '));
                        }
                        html.push(']');
                        texts.push(html.join(''));
                    });
                }
            }
            else {
                var selectelement = that.getSelectedListItem(that, '', true, true);
                $(selectelement).each(function() {
                    texts.push(this.T);
                    values.push(this.V);
                });
            }
            return type === 'text' ? texts : values;
        },

        setSelects: function(values) {
            var that = this;
            this.$selectItems.prop('checked', false);
            var selectelement = [];
            if (that.options.isLazyLoading) {
                that.updateSelectedItemChange(that, values, true);
                selectelement = $(that.$parent).find("ul").find('li').find('input');
            }
            else {
                selectelement = that.$selectItems;
            }
            $.each(values, function(i, value) {
                var selectedobj = selectelement.filter('[value="' + value + '"]');
                $(selectedobj).prop('checked', true);
                //for global filter CR
                if ($(selectedobj).attr('disabled') != 'disabled') {
                    $(selectedobj).parent().parent().addClass('selected');
                }
                else {
                    $(selectedobj).parent().parent().removeClass('selected');
                }
                //for global filter CR
            });
            this.$selectAll.prop('checked', this.$selectItems.length ===
                this.$selectItems.filter(':checked').length);
            this.update();
        },

        enable: function() {
            this.$choice.removeClass('disabled');
        },

        disable: function() {
            this.$choice.addClass('disabled');
        },

        ///// modified for CR 1454
        checkAll: function() {
            if (this.options.isLazyLoading) {
                this.updateAllItemAs(this, true);
                $(this.$parent).find("ul").find('li').find('input').prop('checked', true);
                $(this.$parent).find("ul").find('li').addClass('selected');
                this.$selectAll.filter(':enabled').prop('checked', true);
            } else {
                this.$selectItems.filter(':enabled').prop('checked', true);
                this.$selectGroups.filter(':enabled').prop('checked', true);
                this.$selectAll.filter(':enabled').prop('checked', true);
                //////Added for CR - 1454
                this.$selectGroups.filter(':enabled').parent().parent().addClass('selected');
                this.$selectItems.filter(':enabled').parent().parent().addClass('selected');
                //////Added for CR - 1454
            }
            this.update();
            this.options.onCheckAll();
            //Added for CR -Global Filter

        },

        ///// modified for CR 1454
        uncheckAll: function() {
            if (this.options.isLazyLoading) {
                this.updateAllItemAs(this, false);
                $(this.$parent).find("ul").find('li').find('input').prop('checked', false);
                $(this.$parent).find("ul").find('li').removeClass('selected');
                this.$selectAll.filter(':enabled').prop('checked', false);
            } else {
                this.$selectItems.filter(':enabled').prop('checked', false);
                this.$selectGroups.filter(':enabled').prop('checked', false);
                this.$selectAll.filter(':enabled').prop('checked', false);
                //////Added for CR - 1454
                this.$selectGroups.filter(':enabled').parent().parent().removeClass('selected');
                this.$selectItems.filter(':enabled').parent().parent().removeClass('selected');
                //////Added for CR - 1454
            }
            this.update();
            this.options.onUncheckAll();
            //Added for CR -Global Filter
        },

        focus: function() {
            this.$choice.focus();
            this.options.onFocus();
        },

        blur: function() {
            this.$choice.blur();
            this.options.onBlur();
        },

        refresh: function() {
            this.init();
        },

        filter: function() {
            var that = this,
                text = $.trim(this.$searchInput.parent().find('input').val()).toLowerCase();  ///modified for CR-1454

            if (this.options.isLazyLoading) {
                var ci = this.options.controlId;
                var filteredData = $.grep(this.options.controlData, function(element, index) {
                    return element.T.toLowerCase().indexOf(text.toLowerCase()) >= 0;
                });
                var limitedData = filteredData.slice(0, this.options.itemLimit);
                $(this.$parent).find("li.clearfix").remove();
                $.each(limitedData, function(i, item) {
                    if(item.S == true)
                        $(that.$parent).find("ul").append(that.optionToGenerateHtml(item.T, item.V, item.S, true));
                });
                $.each(limitedData, function(i, item) {
                    if (item.S == false)
                        $(that.$parent).find("ul").append(that.optionToGenerateHtml(item.T, item.V, item.S, true));
                });
                if (this.options.controlData.length > this.options.itemLimit && limitedData.length == this.options.itemLimit) {
                    this.$limitMessage.show();
                }
                else {
                    this.$limitMessage.hide();
                }
                if (limitedData.length > 0) {
                    if (text.length != 0) that.$selectAll.parent().hide();
                    that.$noResults.hide();
                }
                else {
                    that.$selectAll.parent().hide();
                    this.$limitMessage.hide()
                    that.$noResults.show();
                }
                $(that.$parent).find("ul").css('height', 'auto').addClass('in');
                var obj = $(that.$parent).find("ul").find('li').find('input').off('click').on('click', function() {
                    that.updateSelectedItemChange(that, [$(this).val()], $(this).prop('checked'));
                    that.updateSelectAll();
                    that.update();
                    that.updateOptGroupSelect();
                    //////Added for CR - 1454
                    if ($(this).prop('checked')) {
                        $(this).parent().parent().addClass('selected');
                    }
                    else {
                        $(this).parent().parent().removeClass('selected');
                    }
                    //////Added for CR - 1454
                    that.options.onClick({
                        label: $(this).parent().text(),
                        value: $(this).val(),
                        checked: $(this).prop('checked')
                    });

                    if (that.options.single && that.options.isOpen && !that.options.keepOpen) {
                        that.close();
                    }
                });
            }
            if (text.length === 0) {
                if (this.options.isLazyLoading) {
                    this.$selectItems.parent().parent().parent().css('height', '1000px').removeClass('in');   //Added for CR-
                }
                else {
                    this.$selectItems.parent().parent().parent().css('height', '0px').removeClass('in');   //Added for CR-1454
                }
                this.$selectGroups.parent().parent().find('button').addClass('collapsed');  //Added for CR-1454
                this.$selectItems.parent().parent().show();     ///modified for CR-1454
                this.$disableItems.parent().parent().show();    ///modified for CR-1454
                this.$selectGroups.parent().parent().show();    ///modified for CR-1454
                this.$selectGroups.parent().parent().find('button').show();   ///Added for CR-1454
                this.$selectAll.parent().show(); ///Added for CR-1454
                this.$noResults.hide(); /// Added for the 'No result found' message showing even after clearing filter issue for CR - #1454
            }
            else if (!this.options.isLazyLoading) {
                //                this.$selectItems.each(function() {
                //                    //
                //                    var $parent = $(this).parent(),
                //                    $parparent = $(this).parent().parent();
                //                    $parparent[$parent.text().toLowerCase().indexOf(text) < 0 ? 'hide' : 'show']();
                //                    $parent.text().toLowerCase().indexOf(text) < 0 ? '' : $parparent.parent().css('height', 'auto').addClass('in');
                //                });
                this.$selectItems.each(function() {
                    //
                    var $parent = $(this).parent(),
                    $parparent = $(this).parent().parent(), $parenttext = $('#' + $(this).attr('data-group')).parent().text();
                    if ($parenttext.toLowerCase().indexOf(text) > 0 && $parent.text().toLowerCase().indexOf(text) == -1) {
                        $parparent[$parenttext.toLowerCase().indexOf(text) < 0 ? 'hide' : 'show']();
                        $parenttext.toLowerCase().indexOf(text) < 0 ? '' : $parparent.parent().css('height', 'auto').addClass('in');
                    }
                    else {
                        $parparent[$parent.text().toLowerCase().indexOf(text) < 0 ? 'hide' : 'show']();
                        $parent.text().toLowerCase().indexOf(text) < 0 ? '' : $parparent.parent().css('height', 'auto').addClass('in');
                    }
                });

                //this.$disableItems.parent().hide();  ///// commmented for showing disabled items too for CR-#1454
                this.$selectGroups.each(function() {
                    var $parent = $(this).parent();
                    var group = $parent.attr('data-group'),
                    $parparent = $(this).parent().parent(),
                    $items = that.$selectItems.filter(':visible');  ///Commmnedted for CR-#1454
                    $parparent.find('button').addClass('collapsed').show();
                    $parparent[($items.filter('[data-group="' + group + '"]').length === 0 && $parent.text().toLowerCase().indexOf(text) < 0) ? 'hide' : 'show']();  ///modified for CR-1454  added -- '&& $parent.text().toLowerCase().indexOf(text) < 0'
                    ($items.filter('[data-group="' + group + '"]').length > 0) ? $parparent.find('button').removeClass('collapsed') : $parparent.find('button').hide();  ///Added for CR-#1454
                });

                //Check if no matches found
                if (this.$selectItems.filter(':visible').length || this.$selectGroups.filter(':visible').length) {    ///modified for CR-1454  Added ' || this.$selectGroups.filetr(':visible').length'
                    this.$selectAll.parent().show();
                    this.$selectGroups.parent().show();
                    this.$noResults.hide();
                }
                ///Added for CR-#1454
                else if (this.$selectItems.filter(':visible').length) {
                    this.$selectAll.parent().show();
                    this.$selectGroups.parent().show();
                    this.$noResults.hide();
                }
                ///Added for CR-#1454
                else {
                    this.$selectAll.parent().hide();
                    this.$noResults.show();
                }
            }
            this.updateOptGroupSelect();
            this.updateSelectAll();
        },
        updateSelectedItemChange: function(that, arrvalue, totrue) {
            arrvalue = arrvalue.map(function(x) { return x.toLowerCase() });
            var selectedData = $.grep(that.options.controlData, function(element, index) {
                return arrvalue.indexOf(element.V.toLowerCase()) > -1;
            });
            $(selectedData).each(function(i) {
                selectedData[i].S = totrue;
            });
        },
        updateAllItemAs: function(that, isSelectAll) {
            var selectedData = that.options.controlData;
            $(selectedData).each(function(i) {
                selectedData[i].S = isSelectAll;
            });
        },
        getCountAndSelected: function(that) {
            var thats = (that == undefined) ? this : that;
            var selectedItem = $.grep(thats.options.controlData, function(element, index) {
                return element.S == true;
            });

            return [thats.options.controlData.length, selectedItem.length];
        },
        getSelectedListItem: function(that, delimiter, isSelectedItems, asArray) {
            var selectedData = $.grep(that.options.controlData, function(element, index) {
                return element.S == isSelectedItems;
            });
            if (asArray) return selectedData;
            var result = selectedData.map(function(val) {
                return val.V;
            }).join(delimiter);
            return result;
        },
        updatedata: function(newdata) {
            this.options.controlData = newdata;
        }

    };

    $.fn.multipleSelect = function() {
        var option = arguments[0],
            args = arguments,

            value,
            allowedMethods = [
                'getSelects', 'setSelects',
                'enable', 'disable',
                'checkAll', 'uncheckAll',
                'focus', 'blur',
                'refresh', 'setDisabled', 'update', 'filter',
                'getCountAndSelected', 'updatedata'
            ];

        this.each(function() {
            var $this = $(this),
                data = $this.data('multipleSelect'),
                options = $.extend({}, $.fn.multipleSelect.defaults,
                    $this.data(), typeof option === 'object' && option);

            if (!data) {
                data = new MultipleSelect($this, options);
                $this.data('multipleSelect', data);
            }

            if (typeof option === 'string') {
                if ($.inArray(option, allowedMethods) < 0) {
                    throw "Unknown method: " + option;
                }
                value = data[option](args[1]);
            } else {
                data.init();
                if (args[1]) {
                    value = data[args[1]].apply(data, [].slice.call(args, 2));
                }
            }
        });

        return value ? value : this;
    };

    $.fn.multipleSelect.defaults = {
        name: '',
        isOpen: false,
        placeholder: '',
        selectAll: false,
        selectAllText: 'Select all',
        allSelected: 'All selected',
        minumimCountSelected: 10000,
        countSelected: '# of % selected',
        noMatchesFound: 'No matches found',
        multiple: false,
        multipleWidth: 80,
        single: false,
        filter: false,
        width: undefined,
        fixHeight: 250,     ////modified from maxHeight to fixHeight for CR 1454
        container: null,
        position: 'bottom',
        keepOpen: false,
        blockSeparator: '',
        displayValues: false,
        delimiter: ', ',
        hideOptgroupCheckboxes: false,   ///Added for CR - 1454
        hideOptionCheckboxes: false,     ///Added for CR - 1454
        selectAllDefaultName: "select", /////Added for CR - Global filter
        keyupstartsdigit: 2, ///Added for CR - 4936
        onkeyupsearchrequired: false, ///Added for CR - 4936
        searchdesignclass: 'span7', ///Added for CR - 4936
        isLazyLoading: false, ///When using this option we need to controlId,ControlData,Filter as true
        controlId: "sd", //your controlId
        itemLimit: 500,
        controlData: [], //data to bind->eg: [{ControlId:1,ControlValue:[{S:false,T:'text':V:'1'}]}]
        initItemLimit: 0,
        limitMessage: 'shows first 500 values',
        styler: function() { return false; },

        onOpen: function() { return false; },
        onClose: function() { return false; },
        onCheckAll: function() { return false; },
        onUncheckAll: function() { return false; },
        onFocus: function() { return false; },
        onBlur: function() { return false; },
        onOptgroupClick: function() { return false; },
        onClick: function() { return false; },
        onFilter: function() { return false; }
    };
})(jQuery);
