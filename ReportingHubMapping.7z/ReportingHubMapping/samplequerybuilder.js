var demoData = [{ "id": 1, "name": "Urna Ut PC" }, { "id": 2, "name": "Eu Augue LLC" }, { "id": 3, "name": "Commodo Auctor Consulting" }, { "id": 4, "name": "Fringilla Purus Mauris Corporation" }, { "id": 5, "name": "Sodales At Velit Incorporated" }, { "id": 6, "name": "Arcu Institute" }, { "id": 7, "name": "Justo Eu Incorporated" }, { "id": 8, "name": "Elit Limited" }, { "id": 9, "name": "Sed Orci Associates" }, { "id": 10, "name": "Ullamcorper Limited" }, { "id": 11, "name": "Ac Institute" }, { "id": 12, "name": "Enim Nunc Company" }, { "id": 13, "name": "Commodo Tincidunt Nibh Company" }, { "id": 14, "name": "Cursus Luctus Ipsum Associates" }, { "id": 15, "name": "In Ltd" }, { "id": 16, "name": "Non Justo Proin Limited" }, { "id": 17, "name": "Lobortis Company" }, { "id": 18, "name": "Accumsan Neque Et Inc." }, { "id": 19, "name": "Ut Pharetra LLC" }, { "id": 20, "name": "Ac Facilisis Corp." }, { "id": 21, "name": "Morbi Tristique Foundation" }, { "id": 22, "name": "Donec Elementum Company" }, { "id": 23, "name": "In Faucibus Inc." }, { "id": 24, "name": "Amet Risus Donec LLC" }, { "id": 25, "name": "Nulla Tincidunt Neque Limited" }, { "id": 26, "name": "Ipsum Donec Foundation" }, { "id": 27, "name": "Neque Tellus PC" }, { "id": 28, "name": "Aliquet Odio Etiam PC" }, { "id": 29, "name": "Phasellus Fermentum Inc." }, { "id": 30, "name": "Ac Consulting" }, { "id": 31, "name": "Malesuada Vel Industries" }, { "id": 32, "name": "Et Associates" }, { "id": 33, "name": "Vitae Risus Institute" }, { "id": 34, "name": "Iaculis Nec Limited" }, { "id": 35, "name": "Cursus Et Incorporated" }, { "id": 36, "name": "Sem Molestie Sodales Foundation" }, { "id": 37, "name": "Consequat Auctor Limited" }, { "id": 38, "name": "Felis Foundation" }, { "id": 39, "name": "Nunc Limited" }, { "id": 40, "name": "Ultrices LLC" }, { "id": 41, "name": "In Limited" }, { "id": 42, "name": "Etiam Ltd" }, { "id": 43, "name": "Mi Pede Industries" }, { "id": 44, "name": "Tellus Phasellus Corporation" }, { "id": 45, "name": "Sem Company" }, { "id": 46, "name": "Diam Duis Mi Corporation" }, { "id": 47, "name": "Cursus LLC" }, { "id": 48, "name": "Lacus Corporation" }, { "id": 49, "name": "Nunc Sed Company" }, { "id": 50, "name": "Dolor Fusce LLC" }, { "id": 51, "name": "Natoque Penatibus Et Corp." }, { "id": 52, "name": "Libero Est Congue Ltd" }, { "id": 53, "name": "Nisl Arcu Incorporated" }, { "id": 54, "name": "Sit Amet Orci Incorporated" }, { "id": 55, "name": "Maecenas Iaculis Aliquet Limited" }, { "id": 56, "name": "Fermentum Limited" }, { "id": 57, "name": "Imperdiet Limited" }, { "id": 58, "name": "Pede Inc." }, { "id": 59, "name": "Ac Mattis Institute" }, { "id": 60, "name": "Vitae Incorporated" }, { "id": 61, "name": "Tempor Augue Ac Institute" }, { "id": 62, "name": "Eleifend Egestas Sed Limited" }, { "id": 63, "name": "Nulla Facilisis Suspendisse Incorporated" }, { "id": 64, "name": "Sed Institute" }, { "id": 65, "name": "Lacinia At Iaculis LLC" }, { "id": 66, "name": "In Industries" }, { "id": 67, "name": "Consectetuer Adipiscing Associates" }, { "id": 68, "name": "Phasellus Ltd" }, { "id": 69, "name": "Et Lacinia Vitae Industries" }, { "id": 70, "name": "Duis Dignissim Tempor PC" }, { "id": 71, "name": "Commodo Tincidunt Nibh LLC" }, { "id": 72, "name": "Arcu Industries" }, { "id": 73, "name": "Id Mollis Nec Associates" }, { "id": 74, "name": "Quisque Ac Libero PC" }, { "id": 75, "name": "Adipiscing Non Consulting" }, { "id": 76, "name": "Nec PC" }, { "id": 77, "name": "Malesuada Augue Ut LLP" }, { "id": 78, "name": "Nunc LLC" }, { "id": 79, "name": "Auctor Quis LLC" }, { "id": 80, "name": "Tincidunt Tempus Risus Institute" }, { "id": 81, "name": "Euismod Et Commodo Corp." }, { "id": 82, "name": "Nunc Quisque Inc." }, { "id": 83, "name": "Suspendisse Tristique Neque Corporation" }, { "id": 84, "name": "Mauris Elit Dictum Foundation" }, { "id": 85, "name": "Vivamus Nisi Mauris Incorporated" }, { "id": 86, "name": "Placerat Orci Corporation" }, { "id": 87, "name": "Sodales At Velit Limited" }, { "id": 88, "name": "Penatibus Et Limited" }, { "id": 89, "name": "Pretium Neque Incorporated" }, { "id": 90, "name": "Eget Dictum Placerat Ltd" }, { "id": 91, "name": "Ante Blandit Corporation" }, { "id": 92, "name": "Varius Corp." }, { "id": 93, "name": "Vel Venenatis Vel Institute" }, { "id": 94, "name": "Etiam Vestibulum Massa Consulting" }, { "id": 95, "name": "Vulputate Velit Eu Incorporated" }, { "id": 96, "name": "Commodo LLP" }, { "id": 97, "name": "Erat Eget Company" }, { "id": 98, "name": "Justo Nec Company" }, { "id": 99, "name": "Eget Mollis Associates" }, { "id": 100, "name": "Dui Ltd" }];
var isGroupdelete = false;
var typeOfValue_html = '<select class="form-control" name="queryBuilder_TypeOfValue">                        <option value="1">Column</option>             <option value="2">Value</option>                                 </select>'
$("#getsql").addClass("ltblue");
var changedQuery = [];
var flowData = [{ "FlowKey": 1, "flowname": "ANC DME ALL AVMed NA Post" }, { "FlowKey": 50, "flowname": "ANC DME ALL BCBSHigh DE Post" }, { "FlowKey": 3, "flowname": "ANC DME ALL BCBSHigh NA Post" }, { "FlowKey": 44, "flowname": "ANC DME ALL BCBSHigh WV Post" }, { "FlowKey": 214, "flowname": "ANC DME All BCBSMI COM POST" }, { "FlowKey": 174, "flowname": "ANC DME ALL BCBSMI NA Post" }, { "FlowKey": 73, "flowname": "ANC DME ALL CENTENE FL Post" }, { "FlowKey": 70, "flowname": "ANC DME ALL CENTENE TX Post" }, { "FlowKey": 163, "flowname": "ANC DME ALL CLOVER NA Post" }, { "FlowKey": 71, "flowname": "ANC DME ALL COV NA Post" }, { "FlowKey": 2, "flowname": "ANC DME ALL FCARE NA Post" }, { "FlowKey": 31, "flowname": "ANC DME ALL HUM NA Post" }, { "FlowKey": 218, "flowname": "ANC DME ALL HUM NA PRE" }, { "FlowKey": 158, "flowname": "ANC DME ALL MEDICA Aarete NA Post" }, { "FlowKey": 32, "flowname": "ANC DME ALL MMO NA Post" }, { "FlowKey": 151, "flowname": "ANC DME ALL UHC COSMOS Post" }, { "FlowKey": 154, "flowname": "ANC DME ALL UHC CSP Post" }, { "FlowKey": 139, "flowname": "ANC DME ALL VP NA Post" }, { "FlowKey": 40, "flowname": "ANC HCD ALL BCBSHigh NA Post" }, { "FlowKey": 22, "flowname": "ANC HCD ALL BCBSHRZ NASCO Post" }, { "FlowKey": 198, "flowname": "ANC HCD ALL BCBSMI NA Post" }, { "FlowKey": 164, "flowname": "ANC HCD ALL CLOVER NA Post" }, { "FlowKey": 74, "flowname": "ANC HCD ALL COV NA Post" }, { "FlowKey": 10, "flowname": "ANC HCD ALL Emblem NA Post" }, { "FlowKey": 21, "flowname": "ANC HCD ALL FCARE NA Post" }, { "FlowKey": 24, "flowname": "ANC HCD ALL HUM NA Post" }, { "FlowKey": 206, "flowname": "ANC HCD ALL HUM NA Pre" }, { "FlowKey": 11, "flowname": "ANC HCD ALL MMO NA Post" }, { "FlowKey": 63, "flowname": "ANC HCD ALL Simply NA Post" }, { "FlowKey": 54, "flowname": "ANC HCD HIT BCBSHigh DE Post" }, { "FlowKey": 56, "flowname": "ANC HCD HIT BCBSHigh WV Post" }, { "FlowKey": 215, "flowname": "ANC HCD HIT BCBSMI COM POST" }, { "FlowKey": 137, "flowname": "ANC HH ALL BCBSAZ MCARE Post" }, { "FlowKey": 200, "flowname": "ANC HH ALL BCBSHigh DE Post" }, { "FlowKey": 25, "flowname": "ANC HH ALL BCBSHigh NA Post" }, { "FlowKey": 58, "flowname": "ANC HH ALL BCBSHigh WV Post" }, { "FlowKey": 69, "flowname": "ANC HH ALL BCBSMI NA Post" }, { "FlowKey": 193, "flowname": "ANC HH ALL BCBSMI New NA Post" }, { "FlowKey": 94, "flowname": "ANC HH ALL CENTENE NA Post" }, { "FlowKey": 77, "flowname": "ANC HH ALL CENTENE TX Post" }, { "FlowKey": 165, "flowname": "ANC HH ALL CLOVER NA Post" }, { "FlowKey": 159, "flowname": "ANC HH ALL MEDICA Aarete NA Post" }, { "FlowKey": 88, "flowname": "ANC HH ALL TCHP NA Post" }, { "FlowKey": 216, "flowname": "ANC HH All UHC Cosmos Par NA POST" }, { "FlowKey": 148, "flowname": "ANC HH ALL UHC COSMOS Post" }, { "FlowKey": 49, "flowname": "ANC HH ALL UHC XL Post" }, { "FlowKey": 138, "flowname": "ANC HH ALL VP NA Post" }, { "FlowKey": 185, "flowname": "ANC HH DUAL ALL VP NA Post" }, { "FlowKey": 51, "flowname": "ANC HH OAS HUM NA Post" }, { "FlowKey": 194, "flowname": "ANC HH OAS HUM NA Pre" }, { "FlowKey": 210, "flowname": "ANC HH PV BCBSMI COM Post" }, { "FlowKey": 89, "flowname": "ANC HH PV HUM NA Post" }, { "FlowKey": 207, "flowname": "ANC HH PV HUM NA Prepay" }, { "FlowKey": 212, "flowname": "ANC HH PV Humana NA Pre" }, { "FlowKey": 186, "flowname": "ANC SNF ALL CLOVER NA Post" }, { "FlowKey": 45, "flowname": "ANC SNF ALL HUM NA Post" }, { "FlowKey": 157, "flowname": "ANC SNF ALL MEDICA Aarete NA Post" }, { "FlowKey": 108, "flowname": "ANC SNF ALL PRIORITY NA Post" }, { "FlowKey": 166, "flowname": "ANC SNF ALL RUG CLOVER NA Post" }, { "FlowKey": 150, "flowname": "ANC SNF MN MMO NA Post" }, { "FlowKey": 140, "flowname": "ANC SNF RUG BCBSAZ MCARE Post" }, { "FlowKey": 37, "flowname": "ANC SNF RUG BCBSHigh NA Post" }, { "FlowKey": 115, "flowname": "ANC SNF RUG CAREOR NA Post" }, { "FlowKey": 95, "flowname": "ANC SNF RUG CENTENE NA Post" }, { "FlowKey": 43, "flowname": "ANC SNF RUG HUM NA Post" }, { "FlowKey": 17, "flowname": "ANC SNF RUG ICARE NA Post" }, { "FlowKey": 182, "flowname": "ANC SNF RUG KHHTEF NA Post" }, { "FlowKey": 112, "flowname": "ANC SNF RUG Martin NA Post" }, { "FlowKey": 107, "flowname": "ANC SNF RUG PRIORITY NA Post" }, { "FlowKey": 144, "flowname": "ANC SNF RUG UHC COSMOS Post" }, { "FlowKey": 52, "flowname": "ANC SNF RUG UHC XL Post" }, { "FlowKey": 30, "flowname": "ANC SNF RUG UPMC NA Post" }, { "FlowKey": 134, "flowname": "ANC SNF RUG VP NA Post" }, { "FlowKey": 123, "flowname": "GBL DM ALL BCBSHRZ NA Post" }, { "FlowKey": 33, "flowname": "GBL DM ALL BCBSHRZ NASCO Post" }, { "FlowKey": 34, "flowname": "GBL DM ALL BCBSHRZ QBlue Post" }, { "FlowKey": 117, "flowname": "GBL DM ALL BCBSIND NA Post" }, { "FlowKey": 80, "flowname": "GBL DM ALL CENTENE TX Post" }, { "FlowKey": 4, "flowname": "GBL DM ALL COA NA Post" }, { "FlowKey": 5, "flowname": "GBL DM ALL Essence NA Post" }, { "FlowKey": 39, "flowname": "GBL DM ALL FCARE NA Post" }, { "FlowKey": 6, "flowname": "GBL DM ALL HUM NA Post" }, { "FlowKey": 180, "flowname": "GBL DM ALL NHPRI NA Post" }, { "FlowKey": 7, "flowname": "GBL DM ALL S&amp;W NA Post" }, { "FlowKey": 8, "flowname": "GBL DM ALL TCHP NA Post" }, { "FlowKey": 149, "flowname": "GBL SIU ALL HUM NA FWA" }, { "FlowKey": 184, "flowname": "HOSP IP DRG ALL Essence NA Post" }, { "FlowKey": 131, "flowname": "HOSP IP DRG BCBSAZ MCARE Post" }, { "FlowKey": 104, "flowname": "HOSP IP DRG BCBSIND NA Post" }, { "FlowKey": 114, "flowname": "HOSP IP DRG CAREOR NA Post" }, { "FlowKey": 162, "flowname": "HOSP IP DRG CLOVER NA Post" }, { "FlowKey": 103, "flowname": "HOSP IP DRG COA NA Post" }, { "FlowKey": 102, "flowname": "HOSP IP DRG FCARE NA Post" }, { "FlowKey": 116, "flowname": "HOSP IP DRG HUM NA Post" }, { "FlowKey": 217, "flowname": "HOSP IP DRG HUM NA PRE" }, { "FlowKey": 132, "flowname": "HOSP IP DRG KAISER NA Post" }, { "FlowKey": 105, "flowname": "HOSP IP DRG KAISER NA Post" }, { "FlowKey": 155, "flowname": "HOSP IP DRG MEDICA Aarete NA Post" }, { "FlowKey": 96, "flowname": "HOSP IP DRG MMO NA Post" }, { "FlowKey": 179, "flowname": "HOSP IP DRG NEXT NA Post" }, { "FlowKey": 202, "flowname": "HOSP IP DRG OP2 UHC COSMOS POST" }, { "FlowKey": 101, "flowname": "HOSP IP DRG Simply NA Post" }, { "FlowKey": 100, "flowname": "HOSP IP DRG TCHP NA Post" }, { "FlowKey": 201, "flowname": "HOSP IP DRG UHC ALL COSMOS Post" }, { "FlowKey": 205, "flowname": "HOSP IP DRG UHC UNET 2nd POST" }, { "FlowKey": 204, "flowname": "HOSP IP DRG UHC UNET 6th POST" }, { "FlowKey": 135, "flowname": "HOSP IP DRG VP NA Post" }, { "FlowKey": 187, "flowname": "HOSP IP HBA BCBSIND NA Post" }, { "FlowKey": 190, "flowname": "HOSP IP HBA FCARE NA Post" }, { "FlowKey": 177, "flowname": "HOSP IP HBA HUM NA Post" }, { "FlowKey": 191, "flowname": "HOSP IP HBA MMO NA Post" }, { "FlowKey": 188, "flowname": "HOSP IP HBA PRIORITY NA Post" }, { "FlowKey": 189, "flowname": "HOSP IP HBA TCHP NA Post" }, { "FlowKey": 36, "flowname": "HOSP IP IBR FCARE NA Post" }, { "FlowKey": 181, "flowname": "HOSP IP IBR FHCO NA Post" }, { "FlowKey": 13, "flowname": "HOSP IP IBR MEDICA Aarete NA Post" }, { "FlowKey": 27, "flowname": "HOSP IP IBR MMO NA Post" }, { "FlowKey": 14, "flowname": "HOSP IP IBR PREFER NA Post" }, { "FlowKey": 15, "flowname": "HOSP IP IBR PRIORITY NA Post" }, { "FlowKey": 41, "flowname": "HOSP IP IBR S&amp;W NA Post" }, { "FlowKey": 26, "flowname": "HOSP IP IBR TCHP NA Post" }, { "FlowKey": 119, "flowname": "HOSP IP NICU MMO NA Post" }, { "FlowKey": 136, "flowname": "HOSP IP SS BCBSAZ MCARE Post" }, { "FlowKey": 113, "flowname": "HOSP IP SS CAREOR NA Post" }, { "FlowKey": 161, "flowname": "HOSP IP SS CLOVER NA Post" }, { "FlowKey": 18, "flowname": "HOSP IP SS HUM NA Post" }, { "FlowKey": 28, "flowname": "HOSP IP SS HUM ONSITE Post" }, { "FlowKey": 29, "flowname": "HOSP IP SS ICARE NA Post" }, { "FlowKey": 129, "flowname": "HOSP IP SS KAISER NA Post" }, { "FlowKey": 156, "flowname": "HOSP IP SS MEDICA Aarete NA Post" }, { "FlowKey": 121, "flowname": "HOSP IP SS MMO NA Post" }, { "FlowKey": 178, "flowname": "HOSP IP SS NEXT NA Post" }, { "FlowKey": 62, "flowname": "HOSP IP SS Simply NA Post" }, { "FlowKey": 183, "flowname": "HOSP IP SS SS Essence Health NA Post" }, { "FlowKey": 130, "flowname": "HOSP IP SS VP NA Post" }, { "FlowKey": 213, "flowname": "HOSP OP All BCBSMI COM POST" }, { "FlowKey": 173, "flowname": "HOSP OP APC BCBSMI NA Post" }, { "FlowKey": 46, "flowname": "HOSP OP APC ICARE NA Post" }, { "FlowKey": 38, "flowname": "HOSP OP APC ICARE NA Post" }, { "FlowKey": 42, "flowname": "HOSP OP APC MMO NA Post" }, { "FlowKey": 196, "flowname": "HOSP OP IR HUM NA Post" }, { "FlowKey": 208, "flowname": "HOSP OP IR HUM NA Pre" }, { "FlowKey": 133, "flowname": "PHAR RX ALL ENVRx NA Post" }, { "FlowKey": 175, "flowname": "PHAR RX ALL MedImp NA Pre" }, { "FlowKey": 209, "flowname": "PHAR RX ALL OptumRx Validation NA Post" }, { "FlowKey": 203, "flowname": "PHAR RX ALL PDMI NA Post" }, { "FlowKey": 160, "flowname": "PHAR RX CMPND ORx NA Post" }, { "FlowKey": 122, "flowname": "PHAR RX Desk ORx NA Post" }, { "FlowKey": 61, "flowname": "PHAR RX RETAIL MedImp NA Post" }, { "FlowKey": 127, "flowname": "PHAR RX RETAIL OPTCATRx NA Post" }, { "FlowKey": 195, "flowname": "PROF E&amp;M MOD BCBSIND NA Post" }, { "FlowKey": 211, "flowname": "Retail Pharmacy - BCBSMIRx" }];
var metricData = [{ "metricid": 1, "metricname": "ADDITIONALDOC_RECEIVED1" }, { "metricid": 2, "metricname": "ADDITIONALDOC_RECEIVED2" }, { "metricid": 3, "metricname": "ADDITIONALDOC_REQUEST1" }, { "metricid": 4, "metricname": "ADDITIONALDOC_REQUEST2" }, { "metricid": 5, "metricname": "AUDIT_SELECTEDDATE" }, { "metricid": 6, "metricname": "CLIENTAPPROVALDATE" }, { "metricid": 7, "metricname": "CLIENTAPPROVALDATE_DOLLARS" }, { "metricid": 8, "metricname": "CLIENTERRORREASON" }, { "metricid": 9, "metricname": "COLLECTION_RESPONSES_RECEIVED" }, { "metricid": 10, "metricname": "COLLECTIONS_LETTERSENT" }, { "metricid": 11, "metricname": "CONTIGENCYRATE" }, { "metricid": 12, "metricname": "DISPUTE_REPRICE_COMPLETE" }, { "metricid": 13, "metricname": "DISPUTE_REPRICE_SENT_CLIENT" }, { "metricid": 14, "metricname": "DISPUTE_RESULTS_FINDINGS_SENT_TO_CLIENT" }, { "metricid": 15, "metricname": "DISPUTE_RESULTS_FINDINGS_SENT_TO_CLIENT_OVERPAY" }, { "metricid": 16, "metricname": "DISPUTE1_DENIAL_REASON" }, { "metricid": 17, "metricname": "DISPUTE1_OVERTURN_REASON" }, { "metricid": 18, "metricname": "DISPUTE1_OVERTUTNED_DOLLAR" }, { "metricid": 19, "metricname": "DISPUTE2_DENIAL_REASON" }, { "metricid": 20, "metricname": "DISPUTE2_OVERTUTNED_DOLLAR" }, { "metricid": 21, "metricname": "DISPUTE3_OVERTUTNED_DOLLAR" }, { "metricid": 22, "metricname": "DISPUTES1_LETTER_SENT" }, { "metricid": 23, "metricname": "DISPUTES1_MODIFY" }, { "metricid": 24, "metricname": "DISPUTES1_MODIFY_OVERPAY" }, { "metricid": 25, "metricname": "DISPUTES1_OVERPAY" }, { "metricid": 26, "metricname": "DISPUTES1_OVERTURN_PAY" }, { "metricid": 27, "metricname": "DISPUTES1_OVERTURNED" }, { "metricid": 28, "metricname": "DISPUTES1_RECEIVED" }, { "metricid": 29, "metricname": "DISPUTES1_UPHELD" }, { "metricid": 30, "metricname": "DISPUTES1_UPHELD_OVERPAY" }, { "metricid": 31, "metricname": "DISPUTES2_LETTER_SENT" }, { "metricid": 32, "metricname": "DISPUTES2_MODIFY" }, { "metricid": 33, "metricname": "DISPUTES2_MODIFY_OVERPAY" }, { "metricid": 34, "metricname": "DISPUTES2_OVERPAY" }, { "metricid": 35, "metricname": "DISPUTES2_OVERTURN_PAY" }, { "metricid": 36, "metricname": "DISPUTES2_OVERTURNED" }, { "metricid": 37, "metricname": "DISPUTES2_RECEIVED" }, { "metricid": 38, "metricname": "DISPUTES2_UPHELD" }, { "metricid": 39, "metricname": "DISPUTES2_UPHELD_OVERPAY" }, { "metricid": 40, "metricname": "DISPUTES3_MODIFY" }, { "metricid": 41, "metricname": "DISPUTES3_MODIFY_OVERPAY" }, { "metricid": 42, "metricname": "DISPUTES3_OVERPAY" }, { "metricid": 43, "metricname": "DISPUTES3_OVERTURN_PAY" }, { "metricid": 44, "metricname": "DISPUTES3_OVERTURNED" }, { "metricid": 45, "metricname": "DISPUTES3_RECEIVED" }, { "metricid": 46, "metricname": "DISPUTES3_UPHELD" }, { "metricid": 47, "metricname": "DISPUTES3_UPHELD_OVERPAY" }, { "metricid": 48, "metricname": "DOLLAR_TD" }, { "metricid": 49, "metricname": "FINAL_RESULT_FINDING_CALC1_DOLLAR" }, { "metricid": 50, "metricname": "FINAL_RESULT_FINDING_CALC2_DOLLAR" }, { "metricid": 51, "metricname": "FINAL_RESULTS_CANCELLED" }, { "metricid": 52, "metricname": "FINAL_RESULTS_CLOSED" }, { "metricid": 53, "metricname": "FINAL_RESULTS_FINDINGS" }, { "metricid": 54, "metricname": "FINAL_RESULTS_FINDINGS_AMT" }, { "metricid": 55, "metricname": "FINAL_RESULTS_NO_FINDINGS" }, { "metricid": 56, "metricname": "FINDINGSLETTERSENTDATE" }, { "metricid": 57, "metricname": "FINDLETTERSENT_OVERPAY" }, { "metricid": 58, "metricname": "FIRST_RECORDSREQUEST" }, { "metricid": 59, "metricname": "INIT_OVERPAY" }, { "metricid": 60, "metricname": "INITIAL_RESULTS_DENIALREASON" }, { "metricid": 61, "metricname": "INITIAL_RESULTS_FINDINGS_SENT_TO_CLIENT" }, { "metricid": 62, "metricname": "INITIAL_RESULTS_FINDINGS_SENT_TO_CLIENT_OVERPAID_DOLLARS" }, { "metricid": 63, "metricname": "INITIAL_REVIEW" }, { "metricid": 64, "metricname": "INITIAL_REVIEW_DOLLARS" }, { "metricid": 65, "metricname": "INITIAL_REVIEW_FINDINGS" }, { "metricid": 66, "metricname": "INITIAL_REVIEW_FINDINGS_QC" }, { "metricid": 67, "metricname": "INITIAL_REVIEW_NOFINDINGS" }, { "metricid": 68, "metricname": "INITIAL_REVIEW_NOFINDINGS_QC" }, { "metricid": 69, "metricname": "INITIALREVIEW_PROVIDER_SIGNOFF" }, { "metricid": 70, "metricname": "INVOICED_DOLLAR" }, { "metricid": 71, "metricname": "INVOICEDDATE" }, { "metricid": 72, "metricname": "LATE_DISPUTES1_RECEIVED" }, { "metricid": 73, "metricname": "LATE_DISPUTES2_RECEIVED" }, { "metricid": 74, "metricname": "LATE_DISPUTES3_RECEIVED" }, { "metricid": 75, "metricname": "MIGRATED_FLOW" }, { "metricid": 76, "metricname": "MRRECEIVED_AFT_TD" }, { "metricid": 77, "metricname": "NOFINDINGSDATE" }, { "metricid": 78, "metricname": "NORESPONSE_PAID" }, { "metricid": 79, "metricname": "NORESPONSEFROMPROVIDERDATE" }, { "metricid": 80, "metricname": "OVERPAIDAMOUNT_INVOICED" }, { "metricid": 81, "metricname": "OVERPAYMENTSENTFORRETRACTION" }, { "metricid": 82, "metricname": "OVERTURNEDLEVEL1SENTDATE" }, { "metricid": 83, "metricname": "OVERTURNEDLEVEL2SENTDATE" }, { "metricid": 84, "metricname": "PREPAREAUDITDATE" }, { "metricid": 85, "metricname": "PREPAREAUDITDATE1" }, { "metricid": 86, "metricname": "PROCESSLEVEL1KEY" }, { "metricid": 87, "metricname": "QC_AUDIT_COMPLETED" }, { "metricid": 88, "metricname": "QC_AUDIT_ERRORFIX" }, { "metricid": 89, "metricname": "QC_AUDIT_ERRORFIX_DOLLARS" }, { "metricid": 90, "metricname": "QC_AUDIT_FAILED" }, { "metricid": 91, "metricname": "QC_FINDINGS_PASSED" }, { "metricid": 92, "metricname": "QC_NOFINDINGS_PASSED" }, { "metricid": 93, "metricname": "RECORDSRECEIVEDDATE_DOLLAR" }, { "metricid": 94, "metricname": "RECOVERY_INVOICE_PAID" }, { "metricid": 95, "metricname": "RECOVERY_INVOICE_PAIDAMT" }, { "metricid": 96, "metricname": "REPORTDATE" }, { "metricid": 97, "metricname": "REPRICE_CLAIM_COMPLETED" }, { "metricid": 98, "metricname": "REPRICE_CLAIM_COMPLETED_DOLLAR" }, { "metricid": 99, "metricname": "SECOND_RECORDREQUESTDATE" }, { "metricid": 100, "metricname": "SELECTED_CLAIMS" }, { "metricid": 101, "metricname": "SELECTED_CLAIMS_DOLLARS" }, { "metricid": 102, "metricname": "TD_MRREC_AFT_ODAR" }, { "metricid": 103, "metricname": "TD_MRREC_AFT_ODAR_DOLLAR" }, { "metricid": 104, "metricname": "TDSENTDATE" }, { "metricid": 105, "metricname": "THIRDRECORDREQUESTDATE" }];
var dateOperators = ['is_null', 'is_not_null', 'greater', 'greater_or_equal', 'less', 'less_or_equal', 'between', 'not_between'];



function dateFilterValueSetter(rule, value){
    console.log(rule);console.log(value);
  
    rule.$el.find('.rule-value-container input')[0].selectize.setValue(value);
    
}
function setFilter(rule){
    debugger;
    var selected_items = [];
    if(rule.filter!=null){
        selected_items.push(rule.filter.id);
    }
    rule.$el.find('.rule-filter-container select')[0].selectize.setValue(selected_items);
}
function dateFilterInitializer(that) {
    //var that = this;

    if (localStorage.demoData === undefined) {
        $.getJSON('/data/column.json', function (data) {

            localStorage.demoData = JSON.stringify(data);
            data.forEach(function (item) {
                that.addOption(item);
            });
        });
    }
    else {
        JSON.parse(localStorage.demoData).forEach(function (item) {
            that.addOption(item);
        });
    }

}
var dateFilterPluginConfig  = {
    valueField: 'v',
    labelField: 't',
    searchField: 't',
    sortField: 't',
    create: true,
    maxItems: 1,
    plugins: ['remove_button'],
    onInitialize: function () {
        var that = this;
        dateFilterInitializer(that);
        
    }
};
var myFilters = [

    {
        id: 'f.flowkey',
        label: 'Flowname',
        type: 'string',
        plugin: 'selectize',
        plugin_config: {
            valueField: 'FlowKey',
            labelField: 'flowname',
            searchField: 'flowname',
            sortField: 'flowname',
            create: true,
            maxItems: 20,
            plugins: ['remove_button'],
            onInitialize: function () {
                var that = this;
                var data = JSON.stringify(flowData);
                JSON.parse(data).forEach(function (item) {
                    that.addOption(item);
                });
            }
        },
        valueSetter: function (rule, value) {
            rule.$el.find('.rule-value-container input')[0].selectize.setValue(value);
            
        },
        operators: ['in', 'not_in']
    },
    {
        id: 'category',
        label: 'DateColumn',
        type: 'string',
        plugin: 'selectize',
        plugin_config: dateFilterPluginConfig,
        valueSetter:function (rule, value) {
            dateFilterValueSetter(rule, value)
        },
        operators: dateOperators
    },
    {
        id: 'varcharColumn',
        label: 'varchar column',
        type: 'string'

    }, {
        id: 'moneyColumn',
        label: 'Money Column',
        type: 'double',
        validation: {
            min: 0,
            step: 0.01
        }
    }
];

if (localStorage.demoData === undefined || localStorage.demoData =="undefined") {
    $.getJSON('/data/column.json', function (data) {
        localStorage.demoData = JSON.stringify(data);
        data.forEach(function (item) {
            if(item.d =='D'){
                myFilters.push(AddFilter(item.v,item.t));
            }
        });
    });
}
else {
    JSON.parse(localStorage.demoData).forEach(function (item) {
        
        if(item.d =='D'){
            myFilters.push(AddFilter(item.v,item.t));
        }
    });
}
function AddFilter(dateId,dateLlabel){
 var dateFilter =
    {
        id: dateId,
        label: dateLlabel,
        type: 'string',
        plugin: 'selectize',
        plugin_config: dateFilterPluginConfig,
        valueSetter:function (rule, value) {
            dateFilterValueSetter(rule, value)
        },
        operators: dateOperators
    };
    return dateFilter;
}
// // Fix for Selectize
// $('#queryBuilderGoesHere1').on('afterCreateRuleInput.queryBuilder', function(e, rule) {
//     if (rule.filter.plugin == 'selectize') {
//       rule.$el.find('.rule-value-container').css('min-width', '200px')
//         .find('.selectize-control').removeClass('form-control');
//     }
//   });
initializeQueryBuilder(1,'');

function initializeQueryBuilder(id,ruleValue) {
    $("#queryBuilderGoesHere" + id).queryBuilder(
        {
        icons: {
            add_group: 'fa fa-minus-square',
            add_rule: '',
            remove_group: 'fa fa-minus-square',
            remove_rule: '',
            error: 'fa fa-exclamation-circle'
        },
        default_group_flags: {
            no_add_rule: false
        },
        display_empty_filter:true,
        filters: myFilters,
        lang: {
            add_group: 'Add Group',
            add_rule: 'Add Rule',
            errors: {
                number_nan: 'Please enter a value.',
                no_filter: 'Please select a filter.',
                select_empty: 'Please select a value.',
                string_empty: 'Please enter a value.',
                datetime_empty: 'Please select a date.'
            }
        }
        

    }
).on('afterAddGroup.queryBuilder', function(e,group) { 
    // Prevent AND/OR conditions from being disabled when group contains only one rule
   console.log('hi');
    
  }).on("beforeDeleteRule.queryBuilder", function (event, rule) {
    
        if (!isGroupdelete && rule.filter !=null) {
            var confirmBox = confirm('Please confirm if you want to delete the rule?');
            if (!confirmBox) {
                return false;
            }
            else {
                var ssf = rule.$el.find('.rule-filter-container select')[0].selectize;
                ssf.destroy();
                return true;
            }
        }
    }).on("afterUpdateRuleFilter.queryBuilder", function(e,rule){
       // console.log(e);console.log(rule);
       var newValue = rule.filter ? rule.filter.id : '-1';
       if (newValue && (newValue !== '-1')) {
           var ss = rule.$el.find('.rule-filter-container select')[0].selectize;
           if(ss.getValue() !== newValue) {
               ss.setValue(newValue);
           }
       }
    })
    .on("afterCreateRuleFilters.queryBuilder", function (e,rule) {
        
       
        rule.$el.find('.rule-filter-container').find('.form-control').selectize({
            plugins: ['remove_button', 'drag_drop'],
            delimiter: ',',
            persist: false,
            create: false,
            placeholder: "Flows"
        });
        rule.$el.find('.rule-filter-container').css('min-width', '200px')
                .find('.selectize-control').removeClass('form-control');
               
    })
    
    .on("beforeDeleteGroup.queryBuilder", function (event, group) {
       
        var confirmBox1 = confirm('Please confirm if you want to delete the group?');
        if (!confirmBox1) {

            return false;
        } else {
            isGroupdelete = true;
            return true;
        }
    }).on("afterUpdateRuleOperator.queryBuilder", function (rule, previousOperator) {

        var operatorValue = previousOperator.$el.find($.fn.queryBuilder.constructor.selectors.rule_operator).val();

       
    }).on("afterCreateRuleOperators.queryBuilder", function (rule, operators) {
        
    }).on('afterCreateRuleInput.queryBuilder', function (e, rule) {
        if (rule.filter.plugin == 'selectize') {
            rule.$el.find('.rule-value-container').css('min-width', '200px')
                .find('.selectize-control').removeClass('form-control');
        }
    });

}
$("#getsql").on('click', function () {
    debugger;
    var sqlob = $("#queryBuilderGoesHere1").queryBuilder("getSQL", false);
    $("#sql").text(sqlob.sql);
    debugger;

    changedQuery = $('#queryBuilderGoesHere1').queryBuilder("getRules");
    //console.log(changedQuery);
    $("#queryFromJson").queryBuilder({
        filters: myFilters
    });
    $('#queryFromJson').queryBuilder('setRules', changedQuery);

});