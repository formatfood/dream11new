var dataSet = [
	[1, 'Client 1', 11, 1, 'Metric 1', 1, 'flow 1', 1, 'Direct', 'column1', 'json data', 'uuuu', 'some date'],
	[1, 'Client 1', 12, 2, 'Metric 2', 2, 'flow 2', 1, 'Direct', 'column2', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 13, 3, 'Metric 3', 3, 'flow 3', 2, 'Multi', 'column3,column1', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 14, 4, 'Metric 4', 4, 'flow 4', 2, 'Multi', 'column4,column5', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 15, 5, 'Metric 5', 5, 'flow 5', 3, 'conditional', 'column5 is not null and column1 is null', 'json data', 'jjjj', 'somedate']
];

var jsonDataSet = [{
	'mapid': 1,
	'metricid': 1,
	'metricname': 'Metric 1',
	'isCustomElseStatement': true,
	'elseStatementText': 'null',
	'mapdetails': [
		{
			'mapdetailid': 1,
			'flowNames': 'flow1,flow2',
			'flowIds': '1,2',
			'ruleSql': 'column1 is not null',
			'jsonData': null,
			'mappingColumnsName': 'column1,column2',
			'mappingColumnsId': '1,2',
			'isdisableCondition': false,
			'isCustomSqlCondition': true
		},
		{
			'mapdetailid': 2,
			'flowNames': 'flow1,flow2',
			'flowIds': '1,2',
			'ruleSql': 'column1 is not null',
			'jsonData': {
				'condition': 'AND',
				'rules': [
					{
						'id': 'name',
						'field': 'name',
						'type': 'string',
						'input': 'text',
						'operator': 'is_not_null',
						'value': null
					}
				],
				'valid': true
			},
			'mappingColumnsName': 'column1,column2',
			'mappingColumnsId': '1,2',
			'isdisableCondition': false,
			'isCustomSqlCondition': false
		}
	],
	'lastmodifiedby': 'vodriscoll0',
	'lastmodifieddate': '11/2/2018'
}, {
	'mapid': 2,
	'metricid': 2,
	'metricname': 'Metric 2',

	'jsondata': [
		{
		},
		{
		}
	],
	'lastmodifiedby': 'ehumbert1',
	'lastmodifieddate': '8/27/2018'
}, {
	'mapid': 3,
	'metricid': 3,
	'metricname': 'Metric 3',

	'jsondata': [
		{
		},
		{
		}
	],
	'lastmodifiedby': 'glerner2',
	'lastmodifieddate': '6/24/2018'
}, {
	'mapid': 4,
	'metricid': 4,
	'metricname': 'Metric 4',

	'jsondata': [
		{
		},
		{
		}
	],
	'lastmodifiedby': 'glerner2',
	'lastmodifieddate': '6/24/2018'
}
	, {
	'mapid': 5,
	'metricid': 5,
	'metricname': 'Metric 5',

	'jsondata': [
		{
		},
		{
		}
	],
	'lastmodifiedby': 'glerner2',
	'lastmodifieddate': '6/24/2018'
}
];

var jsonClient = [{
	"clientid": 1,
	"clientname": "client1"
}, {
	"clientid": 2,
	"clientname": "client2"
}, {
	"clientid": 3,
	"clientname": "client3"
}];

var jsonMetric = [{
	"metricid": 1,
	"metricname": "Metric1"
}, {
	"metricid": 2,
	"metricname": "Metric2"
}, {
	"metricid": 3,
	"metricname": "Metric3"
}];

var jsonFlow = [{
	"flowid": 1,
	"flowname": "Flow1"
}, {
	"flowid": 2,
	"flowname": "Flow2"
}, {
	"flowid": 3,
	"flowname": "Flow3"
}];

var jsonTypeOfMap = [{
	"typeofmapid": 1,
	"typeofmap": "Direct"
}, {
	"typeofmapid": 2,
	"typeofmap": "Multiple"
}, {
	"typeofmapid": 3,
	"typeofmap": "Conditional"
}];


function format(d) {
	var innerRow = '<div class="row">' +
		"<div class='material-design-btn pull-right'>" +
		"<button class='btn notika-btn-gray btn-reco-mg btn-button-mg waves-effect' onclick='openNav("+d.mapid+")'> Edit </button>" +
		"</div>" +
		"<div class='bsc-tbl'>" +
		"<table class='table table-sc-ex'>" +
		"<thead>" +
		"<tr>" +
		"<th>Case</th>" +
		"<th>Flow Names</th>" +
		"<th>Condition</th>" +
		"<th>Mapping column</th>" +
		"<th>Else</th>" +
		"</tr>" +
		"</thead>" +
		"<tbody>";

	$.each(d.mapdetails, function (index, jsonObject) {
		var id = jsonObject.mapdetailid;
		var flowNames = jsonObject.flowNames;
		var mappingColumns = jsonObject.mappingColumnsName;
		var ruleSqltext = jsonObject.ruleSql;
		innerRow = innerRow + "	<tr>" +

			"<td> when " + id + "</td>" +
			"<td>" + flowNames + "</td>" +
			"<td>" + ruleSqltext + "</td>" +
			"<td>" + mappingColumns + "</td>" +
			"<td></td>" +

			"</tr>"
	});

	innerRow = innerRow + "	<tr>" +

		"<td>else </td>" +
		"<td></td>" +
		"<td></td>" +
		"<td>" + d.elseStatementText + "</td>" +
		"<td>true</td>" +

		"</tr>"


	innerRow = innerRow + "</tbody>" +
		"</table>" +
		"</div></div>";
	return innerRow;
}

(function ($) {
	"use strict";

	$(document).ready(function () {
		var table = $('#data-table-basic').DataTable({
			aaData: jsonDataSet,
			columns: [
				{ data: "metricname", title: "Metric Name" },//4
				{ data: "lastmodifiedby", title: "Last Modified User" },//4
				{ data: "lastmodifieddate", title: "Modified Date" },//4
				{
					title: "Action",
					className: 'details-control',
					orderable: false,
					data: null,
					defaultContent: ''
				}
			],
			// "columnDefs": [
			// 	{
			// 		"targets": [0],
			// 		"visible": false,
			// 		"searchable": true
			// 	}
			// ],
			"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
			order: [[1, 'desc']]
		});

		// Add event listener for opening and closing details
		$('#data-table-basic tbody').on('click', 'td.details-control', function () {
			var tr = $(this).closest('tr');
			var row = table.row(tr);

			if (row.child.isShown()) {
				// This row is already open - close it
				row.child.hide();
				tr.removeClass('shown');
			}
			else {
				// Open this row
				row.child(format(row.data())).show();
				tr.addClass('shown').promise().done(function () {
					//$(".selectpicker").selectpicker();
				});

			}
		});

		// $( "#btnSearch" ).click(function() {
		// 	table.draw();
		//   });
		// $.fn.dataTable.ext.search.push(
		// 	function (settings, data, dataIndex) {
		// 		var client = data[0];
		// 		var metric = data[1];
		// 		var flow = data[2];
		// 		//console.log(data);
		// 		var selectedClient = $('#clientdd').val();
		// 		var selectedMetricsArr = $('#metricdd').val();
		// 		var selectedFlowArr = $('#flowdd').val();

		// 		if ((isNaN(selectedClient) && client === selectedClient) && 
		// 		(!isNaN(selectedMetricsArr) || jQuery.inArray(metric, selectedMetricsArr) !== -1) &&
		// 		(!isNaN(selectedFlowArr) || jQuery.inArray(flow, selectedFlowArr) !== -1)) {
		// 			return true;
		// 		}

		// 		else {
		// 			return false;
		// 		}


		// 	}
		// );

	});

})(jQuery); 