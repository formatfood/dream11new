var dataSet = [
	[1, 'Client 1', 11, 1, 'Metric 1', 1, 'flow 1', 1, 'Direct', 'column1', 'json data', 'uuuu', 'some date'],
	[1, 'Client 1', 12, 2, 'Metric 2', 2, 'flow 2', 1, 'Direct', 'column2', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 13, 3, 'Metric 3', 3, 'flow 3', 2, 'Multi', 'column3,column1', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 14, 4, 'Metric 4', 4, 'flow 4', 2, 'Multi', 'column4,column5', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 15, 5, 'Metric 5', 5, 'flow 5', 3, 'conditional', 'column5 is not null and column1 is null', 'json data', 'jjjj', 'somedate']
];

var jsonDataSet = [{
	"mapid": 1,
	"clientid": 1,
	"clientname": "ABC Client",
	"metricid": 1,
	"metricname": "Metric 1",
	"flowid": 1,
	"flowname": "Flow 1",
	"typeofmapid": 1,
	"typeofmap": "Direct Map - WOC",
	"condition": "",
	"mappingColumns":"Column1",
	"jsondata": [
		{
		},
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "vodriscoll0",
	"lastmodifieddate": "11/2/2018"
}, {
	"mapid": 2,
	"clientid": 1,
	"clientname": "ABC Client",
	"metricid": 1,
	"metricname": "Metric 1",
	"flowid": 2,
	"flowname": "Flow 2",
	"typeofmapid": 2,
	"typeofmap": "Multiple Map-WOC",
	"condition": "",
	"mappingColumns":"Column1,Column2",
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "ehumbert1",
	"lastmodifieddate": "8/27/2018"
}, {
	"mapid": 3,
	"clientid": 1,
	"clientname": "ABC Client",
	"metricid": 1,
	"metricname": "Metric 1",
	"flowid": 3,
	"flowname": "Flow 3",
	"typeofmapid": 3,
	"typeofmap": "Direct Map-WC",
	"condition": "Column1 is not null and Column1 > Column2",
	"mappingColumns":"Column1",	
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "glerner2",
	"lastmodifieddate": "6/24/2018"
}, {
	"mapid": 3,
	"clientid": 1,
	"clientname": "ABC Client",
	"metricid": 1,
	"metricname": "Metric 1",
	"flowid": 4,
	"flowname": "Flow 4",
	"typeofmapid": 4,
	"typeofmap": "Multiple Map-WC",
	"condition": "Column1 is not null and Column1 > Column2",
	"mappingColumns":"Column1,Column2",	
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "glerner2",
	"lastmodifieddate": "6/24/2018"
}
, {
	"mapid": 4,
	"clientid": 1,
	"clientname": "ABC Client",
	"metricid": 1,
	"metricname": "Metric 1",
	"flowid": 5,
	"flowname": "Flow 5",
	"typeofmapid": 5,
	"typeofmap": "Latest",
	"condition": "Column1 is not null and Column1 > Column2#Column1 is not null",
	"mappingColumns":"Column1,Column2#Column3",	
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "glerner2",
	"lastmodifieddate": "6/24/2018"
}
];

var jsonClient = [{
	"clientid": 1,
	"clientname": "client1"
}, {
	"clientid": 2,
	"clientname": "client2"
}, {
	"clientid": 3,
	"clientname": "client3"
}];

var jsonMetric = [{
	"metricid": 1,
	"metricname": "Metric1"
}, {
	"metricid": 2,
	"metricname": "Metric2"
}, {
	"metricid": 3,
	"metricname": "Metric3"
}];

var jsonFlow = [{
	"flowid": 1,
	"flowname": "Flow1"
}, {
	"flowid": 2,
	"flowname": "Flow2"
}, {
	"flowid": 3,
	"flowname": "Flow3"
}];

var jsonTypeOfMap = [{
	"typeofmapid": 1,
	"typeofmap": "Direct"
}, {
	"typeofmapid": 2,
	"typeofmap": "Multiple"
}, {
	"typeofmapid": 3,
	"typeofmap": "Conditional"
}];


function format(d) {
	debugger;
	console.log(d);

	var selectTypeOfMapHtml = '';
	var selected = ' selected '
	$.each(jsonTypeOfMap, function (index, jsonObject) {
		if (jsonObject.typeofmapid != d.typeofmapid) {
			selected = ''
		}
		else { selected = ' selected ' }
		selectTypeOfMapHtml = selectTypeOfMapHtml + '<option value="' + jsonObject.typeofmapid + '" ' + selected + ' >' + jsonObject.typeofmap + '</option>';
	});
	// `d` is the original data object for the row
	return '<div class="row">' +
		'<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">' +
		'<div class="form-example-wrap" style="padding:0">' +
		'<div class="cmp-tb-hd cmp-int-hd">' +
		'<h6> Client Name : <span class="text-light-blue"> ' + d.clientname + ' </span> || Metric Name : <span  class="text-light-blue">' + d.metricname + '</span> || Flow Name : <span  class="text-light-blue"> ' + d.flowname + '</span></h6>' +
		'</div>' +
		'<div class="form-example-int form-horizental">' +
		'<div class="form-group">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'<label class="hrzn-fm">Mapping Type</label>' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<div class="nk-int-st">' +
		'<div class="bootstrap-select fm-cmp-mg" style="width:50%">' +
		'<select class="selectpicker">' +
		'<option value="-1">Select Type Of Map</option>' +
		selectTypeOfMapHtml +

		// '<option>Direct</option>' +
		// '<option selected>Multiple</option>' +
		// '<option>Conditional</option>' +
		'</select>' +
		// '<label><input type="checkbox" class="i-checks" id="typeofmap1"> <i></i> Option two is after click checked</label>'+
		// '<label><input type="checkbox" class="i-checks" id="typeofmap2"> <i></i> Option two is after click checked</label>'+
		// '<label><input type="checkbox" class="i-checks" id="typeofmap3"> <i></i> Option two is after click checked</label>'+
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'<div class="form-example-int form-horizental mg-t-15">' +
		'<div class="form-group">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'<label class="hrzn-fm">Cofiguration</label>' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<div class="nk-int-st">' +
		'<div id="configMAPID">rule will come here</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +

		'<div class="form-example-int mg-t-15">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<button class="btn btn-success notika-btn-success waves-effect">Save</button>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>';
}
(function ($) {
	"use strict";

	$(document).ready(function () {


		var table = $('#data-table-basic').DataTable({
			aaData: jsonDataSet,
			columns: [
				{ data: "clientname", title: "Client Name" },
				{ data: "metricname", title: "Metric Name" },//4
				{ data: "flowname", title: "Flow Name" },//6
				{ data: "typeofmap", title: "Mapping Type" },//8
				{ data: "condition", title: "condition" },//9
				{ data: "mappingColumns", title: "mappings" },//9
				{
					title: "Action",
					className: 'details-control',
					orderable: false,
					data: null,
					defaultContent: ''
				}
			],
			"columnDefs": [
				{
					"targets": [0],
					"visible": false,
					"searchable": true
				}
			],
			"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
		});

		// Add event listener for opening and closing details
		$('#data-table-basic tbody').on('click', 'td.details-control', function () {
			var tr = $(this).closest('tr');
			var row = table.row(tr);

			if (row.child.isShown()) {
				// This row is already open - close it
				row.child.hide();
				tr.removeClass('shown');
			}
			else {
				// Open this row
				row.child(format(row.data())).show();
				tr.addClass('shown').promise().done(function () {
					$(".selectpicker").selectpicker();
				});

			}
		});
		
		$( "#btnSearch" ).click(function() {
			table.draw();
		  });
		$.fn.dataTable.ext.search.push(
			function (settings, data, dataIndex) {
				var client = data[0];
				var metric = data[1];
				var flow = data[2];
				//console.log(data);
				var selectedClient = $('#clientdd').val();
				var selectedMetricsArr = $('#metricdd').val();
				var selectedFlowArr = $('#flowdd').val();

				if ((isNaN(selectedClient) && client === selectedClient) && 
				(!isNaN(selectedMetricsArr) || jQuery.inArray(metric, selectedMetricsArr) !== -1) &&
				(!isNaN(selectedFlowArr) || jQuery.inArray(flow, selectedFlowArr) !== -1)) {
					return true;
				}

				else {
					return false;
				}


			}
		);

	});

})(jQuery); 