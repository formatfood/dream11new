var dataSet = [
	[1, 'Client 1', 11, 1, 'Metric 1', 1, 'flow 1', 1, 'Direct', 'column1', 'json data', 'uuuu', 'some date'],
	[1, 'Client 1', 12, 2, 'Metric 2', 2, 'flow 2', 1, 'Direct', 'column2', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 13, 3, 'Metric 3', 3, 'flow 3', 2, 'Multi', 'column3,column1', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 14, 4, 'Metric 4', 4, 'flow 4', 2, 'Multi', 'column4,column5', 'json data', 'jjjj', 'somedate'],
	[1, 'Client 1', 15, 5, 'Metric 5', 5, 'flow 5', 3, 'conditional', 'column5 is not null and column1 is null', 'json data', 'jjjj', 'somedate']
];

var jsonDataSet = [{
	"mapid": 1,
	"clientid": 1,
	"clientname": "Dablist",
	"metricid": 1,
	"metricname": "Perfect Holiday, The",
	"flowid": 1,
	"flowname": "Chevrolet",
	"typeofmapid": 1,
	"typeofmap": "maestro",
	"configuration": "93221 Florence Junction",
	"jsondata": [
		{
		},
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "vodriscoll0",
	"lastmodifieddate": "11/2/2018"
}, {
	"mapid": 2,
	"clientid": 2,
	"clientname": "Zoonder",
	"metricid": 2,
	"metricname": "Hatful of Rain, A",
	"flowid": 2,
	"flowname": "Mercedes-Benz",
	"typeofmapid": 2,
	"typeofmap": "jcb",
	"configuration": "5 Summerview Park",
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "ehumbert1",
	"lastmodifieddate": "8/27/2018"
}, {
	"mapid": 3,
	"clientid": 3,
	"clientname": "Avavee",
	"metricid": 3,
	"metricname": "Shock Doctrine, The",
	"flowid": 3,
	"flowname": "Nissan",
	"typeofmapid": 3,
	"typeofmap": "diners-club-carte-blanche",
	"configuration": "9 Everett Street",
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "glerner2",
	"lastmodifieddate": "6/24/2018"
}, {
	"mapid": 4,
	"clientid": 4,
	"clientname": "Roodel",
	"metricid": 4,
	"metricname": "Visiteurs du soir, Les (Devil's Envoys, The)",
	"flowid": 4,
	"flowname": "Mitsubishi",
	"typeofmapid": 4,
	"typeofmap": "china-unionpay",
	"configuration": "9839 Lighthouse Bay Parkway",
	"jsondata": [
		{
		},
		{
		},
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "nwoodroofe3",
	"lastmodifieddate": "5/5/2018"
}, {
	"mapid": 5,
	"clientid": 5,
	"clientname": "Zoonder",
	"metricid": 5,
	"metricname": "Blind Shaft (Mang jing)",
	"flowid": 5,
	"flowname": "Chrysler",
	"typeofmapid": 5,
	"typeofmap": "switch",
	"configuration": "9 Sachs Park",
	"jsondata": [
		{
		}
	],
	"lastmodifiedby": "blarmour4",
	"lastmodifieddate": "12/7/2018"
}, {
	"mapid": 6,
	"clientid": 6,
	"clientname": "Tagchat",
	"metricid": 6,
	"metricname": "Israeli Intelligence (Hamosad Hasagur)",
	"flowid": 6,
	"flowname": "Ford",
	"typeofmapid": 6,
	"typeofmap": "jcb",
	"configuration": "26 Ohio Plaza",
	"jsondata": [
		{
		},
		{
		}
	],
	"lastmodifiedby": "dbunce5",
	"lastmodifieddate": "4/7/2019"
}, {
	"mapid": 7,
	"clientid": 7,
	"clientname": "Twimbo",
	"metricid": 7,
	"metricname": "Snowriders",
	"flowid": 7,
	"flowname": "GMC",
	"typeofmapid": 7,
	"typeofmap": "visa",
	"configuration": "78396 Birchwood Street",
	"jsondata": [
		{
		},
		{
		},
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "sstatton6",
	"lastmodifieddate": "12/13/2018"
}, {
	"mapid": 8,
	"clientid": 8,
	"clientname": "Riffwire",
	"metricid": 8,
	"metricname": "Moon Over Parador",
	"flowid": 8,
	"flowname": "Pontiac",
	"typeofmapid": 8,
	"typeofmap": "visa-electron",
	"configuration": "906 Mandrake Road",
	"jsondata": [
		{
		},
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "mmccallister7",
	"lastmodifieddate": "6/16/2018"
}, {
	"mapid": 9,
	"clientid": 9,
	"clientname": "Chatterbridge",
	"metricid": 9,
	"metricname": "Despicable Me 2",
	"flowid": 9,
	"flowname": "Mercury",
	"typeofmapid": 9,
	"typeofmap": "jcb",
	"configuration": "39 Milwaukee Alley",
	"jsondata": [
		{
		}
	],
	"lastmodifiedby": "apoxon8",
	"lastmodifieddate": "10/19/2018"
}, {
	"mapid": 10,
	"clientid": 10,
	"clientname": "Ooba",
	"metricid": 10,
	"metricname": "Stop! Or My Mom Will Shoot",
	"flowid": 10,
	"flowname": "GMC",
	"typeofmapid": 10,
	"typeofmap": "bankcard",
	"configuration": "64 Sommers Circle",
	"jsondata": [
		{
		},
		{
		},
		{
		}
	],
	"lastmodifiedby": "sraymen9",
	"lastmodifieddate": "2/20/2019"
}];

var jsonClient = [{
	"clientid": 1,
	"clientname": "client1"
}, {
	"clientid": 2,
	"clientname": "client2"
}, {
	"clientid": 3,
	"clientname": "client3"
}];

var jsonMetric = [{
	"metricid": 1,
	"metricname": "Metric1"
}, {
	"metricid": 2,
	"metricname": "Metric2"
}, {
	"metricid": 3,
	"metricname": "Metric3"
}];

var jsonFlow = [{
	"flowid": 1,
	"flowname": "Flow1"
}, {
	"flowid": 2,
	"flowname": "Flow2"
}, {
	"flowid": 3,
	"flowname": "Flow3"
}];

var jsonTypeOfMap = [{
	"typeofmapid": 1,
	"typeofmap": "Direct"
}, {
	"typeofmapid": 2,
	"typeofmap": "Multiple"
}, {
	"typeofmapid": 3,
	"typeofmap": "Conditional"
}];


function format(d) {
	debugger;
	console.log(d);

	var selectTypeOfMapHtml = '';
	var selected = ' selected '
	$.each(jsonTypeOfMap, function (index, jsonObject) {
		if (jsonObject.typeofmapid != d.typeofmapid) {
			selected = ''
		}
		else { selected = ' selected ' }
		selectTypeOfMapHtml = selectTypeOfMapHtml + '<option value="' + jsonObject.typeofmapid +'" ' + selected + ' >' + jsonObject.typeofmap + '</option>';
	});
	// `d` is the original data object for the row
	return '<div class="row">' +
		'<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">' +
		'<div class="form-example-wrap" style="padding:0">' +
		'<div class="cmp-tb-hd cmp-int-hd">' +
		'<h4>' + d.clientname + ' ~ ' + d.metricname + ' ~ ' + d.flowname + '</h4>' +
		'</div>' +
		'<div class="form-example-int form-horizental">' +
		'<div class="form-group">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'<label class="hrzn-fm">Mapping Type</label>' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<div class="nk-int-st">' +
		'<div class="bootstrap-select fm-cmp-mg" style="width:50%">' +
		'<select class="selectpicker">'+
		'<option value="-1">Select Type Of Map</option>' +
		selectTypeOfMapHtml +

		// '<option>Direct</option>' +
		// '<option selected>Multiple</option>' +
		// '<option>Conditional</option>' +
		'</select>' +
		// '<label><input type="checkbox" class="i-checks" id="typeofmap1"> <i></i> Option two is after click checked</label>'+
		// '<label><input type="checkbox" class="i-checks" id="typeofmap2"> <i></i> Option two is after click checked</label>'+
		// '<label><input type="checkbox" class="i-checks" id="typeofmap3"> <i></i> Option two is after click checked</label>'+
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'<div class="form-example-int form-horizental mg-t-15">' +
		'<div class="form-group">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'<label class="hrzn-fm">Cofiguration</label>' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<div class="nk-int-st">' +
		'<div id="configMAPID">rule will come here</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +

		'<div class="form-example-int mg-t-15">' +
		'<div class="row">' +
		'<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">' +
		'</div>' +
		'<div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">' +
		'<button class="btn btn-success notika-btn-success waves-effect">Save</button>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>';
}
(function ($) {
	"use strict";

	$(document).ready(function () {


		var table = $('#data-table-basic').DataTable({
			aaData: jsonDataSet,
			columns: [

				{ data: "metricname", title: "Metric Name" },//4
				{ data: "flowname", title: "Flow Name" },//6
				{ data: "typeofmap", title: "Mapping Type" },//8
				{ data: "configuration", title: "Configuration" },//9
				{
					title: "Action",
					className: 'details-control',
					orderable: false,
					data: null,
					defaultContent: ''
				}
			],
			"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
		});

		// Add event listener for opening and closing details
		$('#data-table-basic tbody').on('click', 'td.details-control', function () {
			var tr = $(this).closest('tr');
			var row = table.row(tr);

			if (row.child.isShown()) {
				// This row is already open - close it
				row.child.hide();
				tr.removeClass('shown');
			}
			else {
				// Open this row
				row.child(format(row.data())).show();
				tr.addClass('shown').promise().done(function () {
					$(".selectpicker").selectpicker();
				});

			}
		});
	});

})(jQuery); 