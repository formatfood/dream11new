﻿using System.IO;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Windows.Forms;

namespace ExtractDream11DataIntoExcel
{
    class Program
    {
        static string filePath1 = @"D:\dream11\analyse";
        private static string[] pdfFiles = Directory.GetFiles(filePath1, "*.pdf");
        static string fileOutputPath = @"D:\dream11\KOLvsPNJ-1QVAXQ7UT8ANP-972175718 - 1";
        static string[] TeamPlayers = ("Aaron Finch,Andrew Tye,Axar Patel,Barinder Sran,Chris Gayle,Karun Nair,Lokesh Rahul,Mayank Agarwal,Mohit Sharma,Mujeeb Zadran,Ravichandran Ashwin,Andre Russell,Chris Lynn,Dinesh Karthik,Javon Searles,Kuldeep Yadav,Nitish Rana,Piyush Chawla,Prasidh Krishna,Robin Uthappa,Shubman Gill,Sunil Narine").Split(',');
        static void Main(string[] args)
        {

           // ConvertTextToDataTable(GetTextFromPDF());
           foreach(string file in pdfFiles)
            {
                System.Console.WriteLine(file);
                System.Console.WriteLine(file.Replace(".pdf", ".csv"));
                ConvertTextToDataTable(GetTextFromPDF(file), file.Replace(".pdf", ".csv"));
            }
        }

        private static string GetTextFromPDF(string filePath)
        {
            StringBuilder text = new StringBuilder();
           
            using (PdfReader reader = new PdfReader(filePath))
            {
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                    System.Console.WriteLine(filePath + "  " + i.ToString()+ "//" + reader.NumberOfPages.ToString());
                }
            }

            return text.ToString();
        }

        private static void ConvertTextToDataTable(string text,string outputfile)
        {
            string line;
            int counter = 0;
            // convert string to stream
            byte[] byteArray = Encoding.ASCII.GetBytes(text);
            MemoryStream stream = new MemoryStream(byteArray);
            System.IO.StreamReader streamReader = new System.IO.StreamReader(stream);
            var finalResult = new StringBuilder();
            while((line=streamReader.ReadLine())!=null)
            {
                if (counter > 1)
                {
                    var convertedLine = ConvertLineToCommaSeparated(line);
                    finalResult.Append(convertedLine);
                    System.Console.WriteLine(counter);
                }
                counter++;
            }
            System.IO.File.WriteAllText(outputfile, finalResult.ToString());
            streamReader.Close();
            //Clipboard.SetText(finalResult.ToString());
            System.Console.WriteLine(" {1} - There were {0} lines", counter, outputfile);
            // Suspend the screen.  
            //System.Console.ReadLine();
        }

        private static string ConvertLineToCommaSeparated(string line)
        {
            var finalLine = line.Split(')');
            foreach(string player in TeamPlayers)
            {
                if (finalLine.Length == 2)
                {
                    finalLine[1] = finalLine[1].Replace(player, "," + player);
                    
                }
                else
                {
                    line = line.Replace(player, "," + player);
                }
            }
            if (finalLine.Length == 2)
            {
                line = finalLine[0] + ")" + finalLine[1] + System.Environment.NewLine;
            }
            return line;
        }
    }
}
