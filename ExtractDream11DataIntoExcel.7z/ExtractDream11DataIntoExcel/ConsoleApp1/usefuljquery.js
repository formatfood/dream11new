﻿55create-team__team-selector__player-card__cell create-team__team-selector__player-card__cell__col-player - pa
create-team__team-selector__player-card__cell__col-player__header -- player
light -- team | points
create-team__team-selector__player-card__cell create-team__team-selector__player-card__cell__col-credit - cre
createTeamTabsWrapperSelected_86615 - role
var script = document.createElement('script');
script.src = "https://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js";
document.getElementsByTagName('head')[0].appendChild(script);
var final=''
var row = 1;
    $('table tr').each(function(){
        //var cell = 'table tr:nth-child(' + row + ') td:nth-child(1)';
        finalTeam = finalTeam + $(this)[0].firstElementChild.textContent+',';
        row = row + 1;
    });

$('.create-team__team-selector__player-card__cell__col-player__header').each(function(){
var player=$(this);
var teamPoints = player.next('div.light');
var team =teamPoints.text().split('|')[0];
var points =teamPoints.text().split('|')[1].split(':')[1];
console.log(player.text() + ',' + $.trim(team) + ','+$.trim(points));
//console.log(player.text() + ',' + team+','+points));
    });

var roleText = "BOWL";
//console.log(roleText);

$('.create-team__team-selector__player-card__cell__col-player__header').each(function () {
    var player = $(this);
    var teamPoints = player.next('div.light');
    var team = teamPoints.text().split('|')[0];
    var points = teamPoints.text().split('|')[1].split(':')[1];
    var credit = player.parent().parent().next('div.create-team__team-selector__player-card__cell__col-credit').text();
    //console.log(credit);
    console.log(player.text() + ',' + $.trim(team) + ',' + roleText + ',' + $.trim(points) + ',' + credit);
    final = final + '\n' + player.text() + ',' + $.trim(team) + ',' + roleText + ',' + $.trim(points) + ',' + credit;
    //console.log(player.text() + ',' + team+','+points));
});


var roleText = "WK";
//console.log(roleText);

$('.create-team__team-selector__player-card__cell__col-player__header').each(function () {
    var player = $(this);
    var teamPoints = player.next('div.light');
    var team = teamPoints.text().split('|')[0];
    var points = teamPoints.text().split('|')[1].split(':')[1];
    var credit = player.parent().parent().next('div.create-team__team-selector__player-card__cell__col-credit').text();
    //console.log(credit);
    console.log(player.text() + ',' + $.trim(team) + ',' + roleText + ',' + $.trim(points) + ',' + credit);
    final = final + '\n' + player.text() + ',' + $.trim(team) + ',' + roleText + ',' + $.trim(points) + ',' + credit;
    //console.log(player.text() + ',' + team+','+points));
});