﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Player
    {
        public char Id { get; set; }
        public string PlaeryName { get; set; }
        public string Team { get; set; }
        public string Role { get; set; }
        public double Points { get; set; }
        public double Credits { get; set; }

    }
}
